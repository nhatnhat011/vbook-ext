var DATA = {
    "categories": {
        "ASEAN HUYNDAI CUP 2026": [
            {
                "name": "VTV6",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/VTV6.png",
                "group": "ASEAN HUYNDAI CUP 2026",
                "url": "https://247.dpdns.org/VIP/vtv6/nactha"
            },
            {
                "name": "VTV7",
                "logo": "https://i.ytimg.com/vi/hWt5JN_B66Y/maxresdefault.jpg",
                "group": "ASEAN HUYNDAI CUP 2026",
                "url": "https://247.dpdns.org/VIP/vtv7/nactha"
            }
        ],
        "THỂ THAO QUỐC TẾ": [
            {
                "name": "Sky Sport F1",
                "logo": "https://r2.thesportsdb.com/images/media/channel/logo/p5csyn1620551587.png",
                "group": "THỂ THAO QUỐC TẾ",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=1149423&extension=ts&play_token=1jkVQWGCqc"
            },
            {
                "name": "Sky Sport Tennis",
                "logo": "https://e0.365dm.com/24/01/2048x1152/skysports-sky-sports-tennis_6437040.jpg",
                "group": "THỂ THAO QUỐC TẾ",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=1149433&extension=ts&play_token=Y1kv3yxPS8"
            },
            {
                "name": "Canal+ Sport",
                "logo": "https://upload.wikimedia.org/wikipedia/commons/1/1a/Canal%2B_Sport_2015.png",
                "group": "THỂ THAO QUỐC TẾ",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=958758&extension=ts&play_token=MskDtCSrpn"
            },
            {
                "name": "TNT Sports 1 4Mbps for 4G",
                "logo": "https://media.info/l/o/1/1539.1690027797.png",
                "group": "THỂ THAO QUỐC TẾ",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=894977&extension=ts&play_token=W2HvDO5iES"
            },
            {
                "name": "TNT Sports 2 4Mbps for 4G",
                "logo": "https://media.info/l/o/1/1540.1690027877.png",
                "group": "THỂ THAO QUỐC TẾ",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=1091517&extension=ts&play_token=zKzxFKTNmb"
            },
            {
                "name": "TNT Sports 3 4Mbps for 4G",
                "logo": "https://media.info/l/o/5/5712.1690027954.png",
                "group": "THỂ THAO QUỐC TẾ",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=894979&extension=ts&play_token=RLLwKaJKqY"
            },
            {
                "name": "TNT Sports 4 4Mbps for 4G",
                "logo": "https://media.info/l/o/1/1491.1690027975.png",
                "group": "THỂ THAO QUỐC TẾ",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=894980&extension=ts&play_token=4ofwEIdTU4"
            }
        ],
        "⚽| Thể thao quốc tế": [
            {
                "name": "Canal+ Foot",
                "logo": "https://upload.wikimedia.org/wikipedia/commons/e/eb/Canal%2BFoot.png",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=941405&extension=ts&play_token=ODWyLygMWo"
            },
            {
                "name": "CANAL+ LIVE 1",
                "logo": "https://s1.dmcdn.net/v/JjNMw1Z-Js5kwK7KN/x720",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=941442&extension=ts&play_token=6sw55uPREH"
            },
            {
                "name": "CANAL+ LIVE 2",
                "logo": "https://s1.dmcdn.net/v/JjNMw1Z-Js5kwK7KN/x720",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=941443&extension=ts&play_token=BO2CiGVxUy"
            },
            {
                "name": "CANAL+ LIVE 3",
                "logo": "https://s1.dmcdn.net/v/JjNMw1Z-Js5kwK7KN/x720",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=941444&extension=ts&play_token=lWRMv4h4G6"
            },
            {
                "name": "CANAL+ LIVE 4",
                "logo": "https://s1.dmcdn.net/v/JjNMw1Z-Js5kwK7KN/x720",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=941444&extension=ts&play_token=T8Adfmt7Vu"
            },
            {
                "name": "CANAL+ LIVE 5",
                "logo": "https://s1.dmcdn.net/v/JjNMw1Z-Js5kwK7KN/x720",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=941446&extension=ts&play_token=onKUvLJ1FX"
            },
            {
                "name": "CANAL+ LIVE 6",
                "logo": "https://s1.dmcdn.net/v/JjNMw1Z-Js5kwK7KN/x720",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=941447&extension=ts&play_token=VmOfMyrDfy"
            },
            {
                "name": "CANAL+ LIVE 7",
                "logo": "https://s1.dmcdn.net/v/JjNMw1Z-Js5kwK7KN/x720",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=941449&extension=ts&play_token=uUpqkgtfue"
            },
            {
                "name": "CANAL+ LIVE 8",
                "logo": "https://s1.dmcdn.net/v/JjNMw1Z-Js5kwK7KN/x720",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=941468&extension=ts&play_token=oLegwjYDD5"
            },
            {
                "name": "CANAL+ LIVE 9",
                "logo": "https://s1.dmcdn.net/v/JjNMw1Z-Js5kwK7KN/x720",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.ciao-ott.net:80/play/live.php?mac=00:1A:79:C8:7B:30&stream=941470&extension=ts&play_token=10cpSzSEsB"
            },
            {
                "name": "CANAL+ LIVE 10",
                "logo": "https://s1.dmcdn.net/v/JjNMw1Z-Js5kwK7KN/x720",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=941470&extension=ts&play_token=2SQs9dSZmM"
            },
            {
                "name": "CANAL+ LIVE 11",
                "logo": "https://s1.dmcdn.net/v/JjNMw1Z-Js5kwK7KN/x720",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=941471&extension=ts&play_token=ReuCTADsrG"
            },
            {
                "name": "CANAL+ LIVE 12",
                "logo": "https://cdn.livesoccertv.com/images/channels/thumbnails/canalplus-live-12.png",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=941472&extension=ts&play_token=3EM8alU2An"
            },
            {
                "name": "MUTV",
                "logo": "https://m.media-amazon.com/images/I/611NwkDJjOL.png",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.ciao-ott.net:80/play/live.php?mac=00:1A:79:C8:7B:30&stream=1312824&extension=ts&play_token=3ouilCRXf9"
            },
            {
                "name": "Polsat Sport 1",
                "logo": "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e3/Polsat_Sport_1_2024.svg/250px-Polsat_Sport_1_2024.svg.png",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=1729162&extension=ts&play_token=9JXfYd9pyq"
            },
            {
                "name": "Polsat Sport 2",
                "logo": "https://ipla-e2-42.pluscdn.pl/p/cms_thumbnails/qx/qxn4b9d2175hjjvvy4ehpa92nztaynba.png",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=1729164&extension=ts&play_token=vFbihF9Rmr"
            },
            {
                "name": "Polsat Sport 3",
                "logo": "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d2/Polsat_Sport_3_2024.svg/250px-Polsat_Sport_3_2024.svg.png",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=1729168&extension=ts&play_token=ThvjYQPppG"
            },
            {
                "name": "Max Sport 1 HD",
                "logo": "https://r2.thesportsdb.com/images/media/channel/logo/er6tz11641505761.png",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=228727&extension=ts&play_token=mwh0b4DmEo"
            },
            {
                "name": "Max Sport 2 HD",
                "logo": "https://r2.thesportsdb.com/images/media/channel/logo/8qhlj81641505795.png",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=228726&extension=ts&play_token=1WFblY6SIm"
            },
            {
                "name": "Max Sport 4 HD",
                "logo": "https://msatcable.com/wp-content/uploads/2023/05/xoceudhlccd61ha1z10u8orii5.png",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=228724&extension=ts&play_token=TJrfSv76Xi"
            },
            {
                "name": "Eurosport 1",
                "logo": "https://upload.wikimedia.org/wikipedia/commons/3/37/Eurosport1hd.png",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=933004&extension=ts&play_token=jtuDUMdLno"
            },
            {
                "name": "Eurosport 2",
                "logo": "https://upload.wikimedia.org/wikipedia/commons/d/d5/Eurosport2hd.png",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=933003&extension=ts&play_token=OIqiUqIbWW"
            },
            {
                "name": "Tyc Sport Argentina",
                "logo": "https://television.com.ar/wp-content/uploads/2024/01/276279.jpg",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.ciao-ott.net:80/play/live.php?mac=00:1A:79:C8:7B:30&stream=1090606&extension=ts&play_token=UU20nTSWow"
            }
        ],
        "TVB": [
            {
                "name": "TVB VIỆT NAM",
                "logo": "https://tvbaw-na.s3.us-west-1.amazonaws.com/hb/TVB%20Vietnam%20Banner_Side.jpg",
                "group": "TVB",
                "url": "https://amg01868-amg01868c3-tvbanywhere-us-4491.playouts.now.amagi.tv/playlist1080p.m3u8"
            }
        ],
        "LIVE EVENTS 🔴": [
            {
                "name": "Đèn Âm Hồn: Người Con Gái Nam Xương",
                "logo": "https://daknong.1cdn.vn/2025/02/06/den-am-hon-review-phim-va-lich-chieu-tai-viet-nam.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://s6.kkphimplayer6.com/20250811/miyJKDrj/3500kb/hls/index.m3u8"
            },
            {
                "name": "Làm Giàu Với Ma (Betting With Ghost)",
                "logo": "https://haniff.vn/wp-content/uploads/2024/10/Lam-giau-voi-ma-2.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://s4.phim1280.tv/20250323/KmdatGKe/3000kb/hls/index.m3u8"
            },
            {
                "name": "Doraemon Movie 44: Nobita và cuộc phiêu lưu vào thế giới trong tranh (bản lồng tiếng)",
                "logo": "https://kenh14cdn.com/203336854389633024/2025/5/24/ngangcc690d7e-1620-4524-aafa-a7496c81f6f6-174807929920015425666-1748084313655-17480843144601375971451.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://s6.kkphimplayer6.com/20250827/JfkCJsGc/3500kb/hls/index.m3u8"
            },
            {
                "name": "Ngày Xưa Có Một Chuyện Tình",
                "logo": "https://assets.glxplay.io/images/w700/title/ngay-xua-co-mot-chuyen-tinh_web_backdrop_8b7a5b8cbb5fe245d3a6f7aea524c796.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://s6.kkphimplayer6.com/20250901/w8LN0LND/3500kb/hls/index.m3u8"
            },
            {
                "name": "Bộ Tứ Báo Thủ",
                "logo": "https://images.fptplay53.net/media/OTT/VOD/2025/08/28/bo-tu-bao-thu-fpt-play-1756374565016_Landscape.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://s6.kkphimplayer6.com/20250901/2RZvePPZ/3500kb/hls/index.m3u8"
            },
            {
                "name": "Mưa Trên Cánh Bướm",
                "logo": "https://i.imgur.com/q05fNtW.png",
                "group": "LIVE EVENTS 🔴",
                "url": "https://s6.kkphimplayer6.com/20250918/48nrktLm/3500kb/hls/index.m3u8"
            },
            {
                "name": "Thám Tử Kiên: Kỳ Án Không Đầu",
                "logo": "https://images.fptplay53.net/media/OTT/VOD/2025/09/29/tham-tu-kien-ky-an-khong-dau-fpt-play-1759139646462_Landscape.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://s6.kkphimplayer6.com/20251010/86AEDncn/3500kb/hls/index.m3u8"
            },
            {
                "name": "Mưa Đỏ",
                "logo": "https://baokhanhhoa.vn/file/e7837c02857c8ca30185a8c39b582c03/112025/1_20251116070652.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://vip.opstream90.com/20251118/17952_7bf57028/3000k/hls/mixed.m3u8"
            },
            {
                "name": "Conan Movie 28 - Dư Ảnh Của Độc Nhãn",
                "logo": "https://images.fptplay53.net/media/OTT/VOD/2025/12/26/tham-tu-lung-danh-conan-du-anh-cua-doc-nhan-fpt-play-1766741539032_Landscape.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://vodcdn.fptplay.net/POVOD/encoded/2025/12/28/thamtulungdanhconanduanhcuadocnhan-detectiveconanoneeyedflashback-2025-dolby-mav-bb8d776e6f35fe41/H264/stream.mpd?st=8PSyksBMiL_tvRpq4B3-eg&expires=1767859023"
            },
            {
                "name": "Mang Mẹ Đi Bỏ",
                "logo": "https://hnm.1cdn.vn/thumbs/600x315/2025/05/08/mmdb_poster_first-look_2000x2500px.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://vip.opstream90.com/20251129/18758_e33bdf72/3000k/hls/mixed.m3u8"
            },
            {
                "name": "Trái Tim Què Quặt",
                "logo": "https://images.fptplay53.net/media/OTT/VOD/2025/12/26/trai-tim-que-quat-fpt-play-1766744170691_Landscape.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://s6.kkphimplayer6.com/20251228/0HQf0tP2/3500kb/hls/index.m3u8"
            },
            {
                "name": "Làm Giàu Với Ma Phần 2: Cuộc Chiến Hột Xoàn",
                "logo": "https://images.fptplay53.net/media/OTT/VOD/2025/12/30/lam-giau-voi-ma-cuoc-chien-hot-xoan-fpt-play-1767066672824_Landscape.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://vip.opstream90.com/20260102/21537_fe1af53e/3000k/hls/mixed.m3u8"
            },
            {
                "name": "Quỷ Nhập Tràng",
                "logo": "https://images.fptplay53.net/media/OTT/VOD/2026/01/27/quy-nhap-trang-fpt-play-1769508575571_Landscape.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://s6.kkphimplayer6.com/20260129/HDz8Fu0F/3500kb/hls/index.m3u8"
            },
            {
                "name": "Tử Chiến Trên Không",
                "logo": "https://images.fptplay53.net/media/OTT/VOD/2026/01/23/tu-chien-tren-khong-fpt-play-1769164011330_Landscape.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://rumble.com/hls-vod/72x1ns/playlist.m3u8"
            },
            {
                "name": "Hùng Long Phong Bá Phần 4 - Tập 1",
                "logo": "https://images.fptplay53.net/media/OTT/VOD/2026/02/11/hung-long-phong-ba-4-fpt-play-1770804850859_Landscape.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://rumble.com/hls-vod/73gr0i/playlist.m3u8"
            },
            {
                "name": "Hùng Long Phong Bá Phần 4 - Tập 2",
                "logo": "https://images.fptplay53.net/media/OTT/VOD/2026/02/11/hung-long-phong-ba-4-fpt-play-1770804850859_Landscape.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://rumble.com/hls-vod/73k35o/playlist.m3u8"
            },
            {
                "name": "Hùng Long Phong Bá Phần 4 - Tập 3",
                "logo": "https://images.fptplay53.net/media/OTT/VOD/2026/02/11/hung-long-phong-ba-4-fpt-play-1770804850859_Landscape.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://rumble.com/hls-vod/73os1q/playlist.m3u8"
            },
            {
                "name": "Hùng Long Phong Bá Phần 4 - Tập 4",
                "logo": "https://images.fptplay53.net/media/OTT/VOD/2026/02/11/hung-long-phong-ba-4-fpt-play-1770804850859_Landscape.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://rumble.com/hls-vod/73s4u6/playlist.m3u8"
            },
            {
                "name": "Hùng Long Phong Bá Phần 4 - Tập 5",
                "logo": "https://images.fptplay53.net/media/OTT/VOD/2026/02/11/hung-long-phong-ba-4-fpt-play-1770804850859_Landscape.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://rumble.com/hls-vod/73txdq/playlist.m3u8"
            },
            {
                "name": "Hùng Long Phong Bá Phần 4 - Tập Cuối",
                "logo": "https://images.fptplay53.net/media/OTT/VOD/2026/02/11/hung-long-phong-ba-4-fpt-play-1770804850859_Landscape.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://rumble.com/hls-vod/73vrdu/playlist.m3u8"
            },
            {
                "name": "Thế Hệ Kỳ Tích",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/Th%E1%BA%BF%20H%E1%BB%87%20K%E1%BB%B3%20T%C3%ADch.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://rumble.com/hls-vod/745t9a/playlist.m3u8"
            },
            {
                "name": "Tay Anh Giữ Một Vì Sao",
                "logo": "https://thegioidienanh.vn/stores/news_dataimages/2025/092025/14/13/in_social/tay-anh-giu-mot-vi-sao-payoff-poster-social-khoi-chieu-0310202520250914134014.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://vip.opstream90.com/20260102/21538_3a9ba451/3000k/hls/mixed.m3u8"
            },
            {
                "name": "Truy Tìm Long Diên Hương",
                "logo": "https://cdn-images.vtv.vn/zoom/554_346/66349b6076cb4dee98746cf1/2025/09/19/truy-tim-long-dien-huong-67756442926310209483416-92025497027105625698228.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://rumble.com/hls-vod/74h9mw/playlist.m3u8"
            },
            {
                "name": "Út Lan: Oán Linh Giữ Của",
                "logo": "https://images.fptplay53.net/media/OTT/VOD/2026/03/13/ut-lan-oan-linh-giu-cua-fpt-play-1773395168032_Background_origin.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://vip.opstream90.com/20260213/24963_b4f6926d/3000k/hls/mixed.m3u8"
            },
            {
                "name": "Khế Ước Bán Dâu",
                "logo": "https://tintuc-divineshop.cdn.vccloud.vn/wp-content/uploads/2025/08/164142635_khe-uoc-ban-dau.webp",
                "group": "LIVE EVENTS 🔴",
                "url": "https://s6.kkphimplayer6.com/20260118/tdyKqxYZ/3500kb/hls/index.m3u8"
            },
            {
                "name": "Thiên Đường Máu",
                "logo": "https://images.fptplay53.net/media/OTT/VOD/2026/03/13/thien-duong-mau-fpt-play-1773396128871_Landscape.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://s6.kkphimplayer6.com/20260320/02bq9QLy/3500kb/hls/index.m3u8"
            },
            {
                "name": "Cục Vàng Của Ngoại",
                "logo": "https://images.fptplay53.net/media/OTT/VOD/2026/03/27/cuc-vang-cua-ngoai-fpt-play-1774595783778_Landscape.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://s6.kkphimplayer6.com/20260403/6UwV8LAv/3500kb/hls/index.m3u8"
            },
            {
                "name": "Nhà Mình Đi Thôi",
                "logo": "https://images.fptplay53.net/media/OTT/VOD/2026/04/29/nha-minh-di-thoi-fpt-play-1777439633547_Landscape.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://vip.opstream90.com/20260502/30774_da58e2e4/3000k/hls/mixed.m3u8"
            },
            {
                "name": "Cuốc Xe Âm Phủ - Tập 1",
                "logo": "https://images.fptplay53.net/media/OTT/VOD/2026/04/30/cuoc-xe-am-phu-fpt-play-1777541165464_Background_origin.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://v7.kkphimplayer7.com/20260502/89qXv3Fa/3500kb/hls/index.m3u8"
            },
            {
                "name": "Cuốc Xe Âm Phủ - Tập 2",
                "logo": "https://images.fptplay53.net/media/OTT/VOD/2026/04/30/cuoc-xe-am-phu-fpt-play-1777541165464_Background_origin.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://v7.kkphimplayer7.com/20260503/Lp2p18eb/3500kb/hls/index.m3u8"
            },
            {
                "name": "Cuốc Xe Âm Phủ - Tập 3",
                "logo": "https://images.fptplay53.net/media/OTT/VOD/2026/04/30/cuoc-xe-am-phu-fpt-play-1777541165464_Background_origin.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://v7.kkphimplayer7.com/20260504/9JB48ezG/3500kb/hls/index.m3u8"
            },
            {
                "name": "Cuốc Xe Âm Phủ - Tập 4",
                "logo": "https://images.fptplay53.net/media/OTT/VOD/2026/04/30/cuoc-xe-am-phu-fpt-play-1777541165464_Background_origin.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://v7.kkphimplayer7.com/20260504/xNE4czZl/3500kb/hls/index.m3u8"
            },
            {
                "name": "Cuốc Xe Âm Phủ - Tập Cuối",
                "logo": "https://images.fptplay53.net/media/OTT/VOD/2026/04/30/cuoc-xe-am-phu-fpt-play-1777541165464_Background_origin.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://v7.kkphimplayer7.com/20260505/6REaXK8f/3500kb/hls/index.m3u8"
            },
            {
                "name": "Nhà Hai Chủ",
                "logo": "https://images.fptplay53.net/media/OTT/VOD/2026/04/29/nha-hai-chu-fpt-play-1777448554178_Landscape.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://v7.kkphimplayer7.com/20260505/YnFXHB6A/3500kb/hls/index.m3u8"
            },
            {
                "name": "Thỏ Ơi",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/Th%E1%BB%8F%20%C6%A0i.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://v7.kkphimplayer7.com/20260531/mazEQT6f/3500kb/hls/index.m3u8"
            },
            {
                "name": "Hoàng Tử Quỷ",
                "logo": "https://cdn.galaxycine.vn/media/2025/11/25/hoang-tu-quy-750_1764065943548.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://v7.kkphimplayer7.com/20260615/qtiKqvFo/3500kb/hls/index.m3u8"
            },
            {
                "name": "Báu Vật Trời Cho",
                "logo": "https://img-zlr1.tv360.vn/image1/2026/06/03/22/bc4677df/bc4677df-dbcd-4a57-844b-390414aa1778_640_360.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://v7.kkphimplayer7.com/20260617/QgEs8NDH/index.m3u8"
            },
            {
                "name": "Cưới Vợ Cho Cha",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/cuoivochocha.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://v7.kkphimplayer7.com/20260711/ATJuS0IV/3500kb/hls/index.m3u8"
            },
            {
                "name": "Tài",
                "logo": "https://images.fptplay53.net/media/OTT_ECS/2026/07/27/tai20261920x1080s_1785141290941.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://v7.kkphimplayer7.com/20260729/UgOYpPkC/3500kb/hls/index.m3u8"
            },
            {
                "name": "Oshi No Ko Phần 3 - Tập 1",
                "logo": "https://images.fptplay53.net/media/OTT/VOD/2026/01/12/dua-con-cua-than-tuong-phan-3-fpt-play-1768204408459_Background_origin.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://rumble.com/hls-vod/72av32/playlist.m3u8"
            },
            {
                "name": "Oshi No Ko Phần 3 - Tập 2",
                "logo": "https://images.fptplay53.net/media/OTT/VOD/2026/01/12/dua-con-cua-than-tuong-phan-3-fpt-play-1768204408459_Background_origin.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://rumble.com/hls-vod/72nhy6/playlist.m3u8"
            },
            {
                "name": "Oshi No Ko Phần 3 - Tập 3",
                "logo": "https://images.fptplay53.net/media/OTT/VOD/2026/01/12/dua-con-cua-than-tuong-phan-3-fpt-play-1768204408459_Background_origin.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://rumble.com/hls-vod/73bg84/playlist.m3u8"
            },
            {
                "name": "Oshi No Ko Phần 3 - Tập 4",
                "logo": "https://images.fptplay53.net/media/OTT/VOD/2026/01/12/dua-con-cua-than-tuong-phan-3-fpt-play-1768204408459_Background_origin.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://rumble.com/hls-vod/73gpe4/playlist.m3u8"
            },
            {
                "name": "Oshi No Ko Phần 3 - Tập 5",
                "logo": "https://images.fptplay53.net/media/OTT/VOD/2026/01/12/dua-con-cua-than-tuong-phan-3-fpt-play-1768204408459_Background_origin.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://rumble.com/hls-vod/73uq6q/playlist.m3u8"
            },
            {
                "name": "Oshi No Ko Phần 3 - Tập 6",
                "logo": "https://images.fptplay53.net/media/OTT/VOD/2026/01/12/dua-con-cua-than-tuong-phan-3-fpt-play-1768204408459_Background_origin.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://vip.opstream90.com/20260219/25424_5534491f/3000k/hls/mixed.m3u8"
            },
            {
                "name": "Oshi No Ko Phần 3 - Tập 7",
                "logo": "https://images.fptplay53.net/media/OTT/VOD/2026/01/12/dua-con-cua-than-tuong-phan-3-fpt-play-1768204408459_Background_origin.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://rumble.com/hls-vod/74da00/playlist.m3u8"
            },
            {
                "name": "Oshi No Ko Phần 3 - Tập 8",
                "logo": "https://images.fptplay53.net/media/OTT/VOD/2026/01/12/dua-con-cua-than-tuong-phan-3-fpt-play-1768204408459_Background_origin.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://vip.opstream90.com/20260305/26504_404d52bf/3000k/hls/mixed.m3u8"
            },
            {
                "name": "Oshi No Ko Phần 3 - Tập 9",
                "logo": "https://images.fptplay53.net/media/OTT/VOD/2026/01/12/dua-con-cua-than-tuong-phan-3-fpt-play-1768204408459_Background_origin.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://vip.opstream90.com/20260312/26990_72417e4a/3000k/hls/mixed.m3u8"
            },
            {
                "name": "Oshi No Ko Phần 3 - Tập 10",
                "logo": "https://images.fptplay53.net/media/OTT/VOD/2026/01/12/dua-con-cua-than-tuong-phan-3-fpt-play-1768204408459_Background_origin.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://rumble.com/hls-vod/757w6u/playlist.m3u8"
            },
            {
                "name": "Oshi No Ko Phần 3 - Tập 11",
                "logo": "https://images.fptplay53.net/media/OTT/VOD/2026/01/12/dua-con-cua-than-tuong-phan-3-fpt-play-1768204408459_Background_origin.jpg",
                "group": "LIVE EVENTS 🔴",
                "url": "https://rumble.com/hls-vod/75uhgc/playlist.m3u8"
            }
        ],
        "Sự Kiện TV360": [
            {
                "name": "TV360+1",
                "logo": "https://img-zlr1.tv360.vn/image1/2026/04/15/22/1776266760359/ba1ca843cd06_480_270.png",
                "group": "Sự Kiện TV360",
                "url": "https://vmttv.dpdns.org/tv360/?id=tv360-1",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "TV360+2",
                "logo": "https://img-ali1.tv360.vn/image1/2024/09/24/21/1727189794311/c4d18ecff9f7_640_360.png",
                "group": "Sự Kiện TV360",
                "url": "https://vmttv.dpdns.org/tv360/?id=tv360-2",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "TV360+3",
                "logo": "https://img-ali1.tv360.vn/image1/2024/09/24/21/1727189872609/e569653d09d3_640_360.png",
                "group": "Sự Kiện TV360",
                "url": "https://vmttv.dpdns.org/tv360/?id=tv360-3",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "TV360+4",
                "logo": "https://img-ali1.tv360.vn/image1/2024/09/24/21/1727189917617/5db9e5a7d0fd_640_360.png",
                "group": "Sự Kiện TV360",
                "url": "https://vmttv.dpdns.org/tv360/?id=tv360-4",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "TV360+5",
                "logo": "https://img-ali1.tv360.vn/image1/2024/09/24/21/1727189978632/51f31c767a91_640_360.png",
                "group": "Sự Kiện TV360",
                "url": "https://vmttv.dpdns.org/tv360/?id=tv360-5",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "TV360+6",
                "logo": "https://img-ali1.tv360.vn/image1/2024/09/24/22/1727190010448/7463a4b5c14d_640_360.png",
                "group": "Sự Kiện TV360",
                "url": "https://vmttv.dpdns.org/tv360/?id=tv360-6",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "TV360+7",
                "logo": "https://img-ali1.tv360.vn/image1/2024/09/24/22/1727190077791/4922144877f1_640_360.png",
                "group": "Sự Kiện TV360",
                "url": "https://vmttv.dpdns.org/tv360/?id=tv360-7",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "TV360+8",
                "logo": "https://img-ali1.tv360.vn/image1/2024/09/24/22/172719012995/8df54b2f7576_640_360.png",
                "group": "Sự Kiện TV360",
                "url": "https://vmttv.dpdns.org/tv360/?id=tv360-8",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "TV360+9",
                "logo": "https://img-ali1.tv360.vn/image1/2024/09/30/22/1727709197325/1be646ba55c5_640_360.png",
                "group": "Sự Kiện TV360",
                "url": "https://vmttv.dpdns.org/tv360/?id=tv360-9",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "TV360+10",
                "logo": "https://img-ali1.tv360.vn/image1/2025/09/30/16/1759223393533/4ff09f8a4b49_640_360.png",
                "group": "Sự Kiện TV360",
                "url": "https://vmttv.dpdns.org/tv360/?id=tv360-10",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "TV360+11",
                "logo": "https://img-ali1.tv360.vn/image1/2025/09/30/16/175922342147/3c89be41fe63_640_360.png",
                "group": "Sự Kiện TV360",
                "url": "https://vmttv.dpdns.org/tv360/?id=tv360-11",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "TV360+12",
                "logo": "https://img-ali1.tv360.vn/image1/2026/03/05/10/1772681417916/2433e49579ab_640_360.png",
                "group": "Sự Kiện TV360",
                "url": "https://vmttv.dpdns.org/tv360/?id=tv360-12",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "TV360+13",
                "logo": "https://img-zlr1.tv360.vn/image1/2026/05/15/01/1778782670293/dd4067f28084_640_360.png",
                "group": "Sự Kiện TV360",
                "url": "https://vmttv.dpdns.org/tv360/?id=tv360-13",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "TV360+14",
                "logo": "https://img-zlr1.tv360.vn/image1/2026/05/15/01/177878325467/bbecb3ccb477_640_360.png",
                "group": "Sự Kiện TV360",
                "url": "https://vmttv.dpdns.org/tv360/?id=tv360-14",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "TV360+15",
                "logo": "https://img-zlr1.tv360.vn/image1/2026/05/15/01/1778783528367/ddfa21d56253_640_360.png",
                "group": "Sự Kiện TV360",
                "url": "https://vmttv.dpdns.org/tv360/?id=tv360-15",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "TV360 Promo",
                "logo": "https://img-zlr1.tv360.vn/image1/2025/09/17/17/175810574912/a5f8181388ab_640_360.png",
                "group": "Sự Kiện TV360",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=9904",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            }
        ],
        "Rạp Phim": [
            {
                "name": "360 Phim Việt",
                "logo": "https://img-zlr1.tv360.vn/image1/2026/04/07/15/1775549899305/f54a93a767c5_640_360.png",
                "group": "Rạp Phim",
                "url": "https://vmttv.dpdns.org/tv360/?id=phim-viet",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "360 Phim Âu Mỹ",
                "logo": "https://img-zlr1.tv360.vn/image1/2026/04/09/08/1775697767861/9a6dc88794cf_640_360.png",
                "group": "Rạp Phim",
                "url": "https://vmttv.dpdns.org/tv360/?id=phim-au-my",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "360 Hoạt hình",
                "logo": "https://img-zlr1.tv360.vn/image1/2026/04/07/15/1775549978212/fcfc9c6d7919_640_360.png",
                "group": "Rạp Phim",
                "url": "https://vmttv.dpdns.org/tv360/?id=hoat-hinh",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "360 Phim Hoa Ngữ",
                "logo": "https://img-zlr1.tv360.vn/image1/2026/04/09/08/1775697736867/3854900b7263_640_360.png",
                "group": "Rạp Phim",
                "url": "https://vmttv.dpdns.org/tv360/?id=360-hoa-ngu",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "360 Hành Động Châu Á",
                "logo": "https://img-zlr1.tv360.vn/image1/2026/04/08/10/1775617851169/1f38a5af77c1_640_360.png",
                "group": "Rạp Phim",
                "url": "https://vmttv.dpdns.org/tv360/?id=360-hanh-dong-chau-a",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "360 K-Drama",
                "logo": "https://img-zlr1.tv360.vn/image1/2026/04/09/21/1775744591740/79928f9b003f_640_360.png",
                "group": "Rạp Phim",
                "url": "https://vmttv.dpdns.org/tv360/?id=360-k-drama",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "360 Hài - Tình Cảm",
                "logo": "https://img-zlr1.tv360.vn/image1/2026/04/13/13/1776063183880/03439dc9da19_640_360.png",
                "group": "Rạp Phim",
                "url": "https://vmttv.dpdns.org/tv360/?id=360-hai-tinh-cam",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "360 Phim Kinh Điển",
                "logo": "https://img-zlr1.tv360.vn/image1/2026/04/13/13/1776063200976/6ced2ef539a4_640_360.png",
                "group": "Rạp Phim",
                "url": "https://vmttv.dpdns.org/tv360/?id=360-phim-kinh-dien",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "",
                "logo": "",
                "group": "Rạp Phim",
                "url": "https://liveh12vng.vtvprime.vn/hls/ONSPORT1/04.m3u8"
            }
        ],
        "Sự Kiện VTVPrime": [
            {
                "name": "VTVPrime 2",
                "logo": "https://vtvprime.vn/sideLogoBig.png",
                "group": "Sự Kiện VTVPrime",
                "url": "https://liveh12vng.vtvprime.vn/hls/ONSPORT2/04.m3u8"
            },
            {
                "name": "VTVPrime 3",
                "logo": "https://vtvprime.vn/sideLogoBig.png",
                "group": "Sự Kiện VTVPrime",
                "url": "https://liveh12vng.vtvprime.vn/hls/ONSPORT3/04.m3u8"
            },
            {
                "name": "VTVPrime 4",
                "logo": "https://vtvprime.vn/sideLogoBig.png",
                "group": "Sự Kiện VTVPrime",
                "url": "https://liveh12vng.vtvprime.vn/hls/ONSPORT4/04.m3u8"
            },
            {
                "name": "VTVPrime 5",
                "logo": "https://vtvprime.vn/sideLogoBig.png",
                "group": "Sự Kiện VTVPrime",
                "url": "https://liveh12vng.vtvprime.vn/hls/ONSPORT5/04.m3u8"
            },
            {
                "name": "VTVPrime 6",
                "logo": "https://vtvprime.vn/sideLogoBig.png",
                "group": "Sự Kiện VTVPrime",
                "url": "https://liveh12vng.vtvprime.vn/hls/ONSPORT6/04.m3u8"
            },
            {
                "name": "VTVPrime 7",
                "logo": "https://vtvprime.vn/sideLogoBig.png",
                "group": "Sự Kiện VTVPrime",
                "url": "https://liveh12vng.vtvprime.vn/hls/ONSPORT7/04.m3u8"
            },
            {
                "name": "VTVPrime 8",
                "logo": "https://vtvprime.vn/sideLogoBig.png",
                "group": "Sự Kiện VTVPrime",
                "url": "https://liveh12vng.vtvprime.vn/hls/ONSPORT8/04.m3u8"
            },
            {
                "name": "VTVPrime 9",
                "logo": "https://vtvprime.vn/sideLogoBig.png",
                "group": "Sự Kiện VTVPrime",
                "url": "https://liveh12vng.vtvprime.vn/hls/ONSPORT9/04.m3u8"
            },
            {
                "name": "VTVPrime 10",
                "logo": "https://vtvprime.vn/sideLogoBig.png",
                "group": "Sự Kiện VTVPrime",
                "url": "https://liveh12vng.vtvprime.vn/hls/ONSPORT10/04.m3u8"
            },
            {
                "name": "VTVPrime 11",
                "logo": "https://vtvprime.vn/sideLogoBig.png",
                "group": "Sự Kiện VTVPrime",
                "url": "https://livevliatmcdw.seenow.vn/live/data8/SKSS1/Live_DASHDRM/SKSS1.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "VTVPrime 12",
                "logo": "https://vtvprime.vn/sideLogoBig.png",
                "group": "Sự Kiện VTVPrime",
                "url": "https://livevliatmcdw.seenow.vn/live/data8/SKSS2/Live_DASHDRM/SKSS2.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            }
        ],
        "Sự Kiện FPT PLAY": [
            {
                "name": "Sự Kiện 4",
                "logo": "https://images.fptplay53.net/media/home_event/OTT_ECS/2026/08/11/chess-11-a_1786419414384.jpg",
                "group": "Sự Kiện FPT PLAY",
                "url": "https://vips-livecdn.fptplay.net/live/media/su-kien-04/hls_avc_v6/index.m3u8"
            },
            {
                "name": "Sự Kiện 6",
                "logo": "https://images.fptplay53.net/media/home_event/OTT_ECS/2026/08/11/chess-11-b_1786419601541.jpg",
                "group": "Sự Kiện FPT PLAY",
                "url": "https://vips-livecdn.fptplay.net/live/media/su-kien-06/hls_avc_v6/index.m3u8"
            },
            {
                "name": "Sự Kiện 7",
                "logo": "https://images.fptplay53.net/media/home_event/OTT_ECS/2026/08/11/11_1786419793454.jpg",
                "group": "Sự Kiện FPT PLAY",
                "url": "https://vips-livecdn.fptplay.net/live/media/su-kien-07/hls_avc_v6/index.m3u8"
            }
        ],
        "VTV": [
            {
                "name": "VTV1",
                "logo": "https://i.ytimg.com/vi/dGohEWXz7Sk/maxresdefault.jpg",
                "group": "VTV",
                "url": "https://vips-livecdn.fptplay.net/live/media/vtv1/live247-hls-avc/vtv1-avc1_5600000=10000-mp4a_131600=20000.m3u8"
            },
            {
                "name": "VTV2",
                "logo": "https://i.ytimg.com/vi/Cim-egsLkqw/maxresdefault.jpg",
                "group": "VTV",
                "url": "https://vips-livecdn.fptplay.net/live/media/vtv2/live247-hls-avc/vtv2-avc1_5600000=10000-mp4a_131600=20000.m3u8"
            },
            {
                "name": "VTV3",
                "logo": "https://i.ytimg.com/vi/4jr8Y13NSME/maxresdefault.jpg",
                "group": "VTV",
                "url": "https://vips-livecdn.fptplay.net/live/media/vtv3/live247-hls-avc/vtv3-avc1_5600000=10000-mp4a_131600=20000.m3u8"
            },
            {
                "name": "VTV4",
                "logo": "https://i.ytimg.com/vi/Opv4PmUyi8g/maxresdefault.jpg",
                "group": "VTV",
                "url": "https://vips-livecdn.fptplay.net/live/media/vtv4/live247-hls-avc/vtv4-avc1_5600000=10000-mp4a_131600=20000.m3u8"
            },
            {
                "name": "Vietnam Today",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/VietnamToday.jpg",
                "group": "VTV",
                "url": "https://vips-livecdn.fptplay.net/live/media/vietnamtoday/live-hls-avc/vietnamtoday-avc1_4000000=10000-mp4a_131600=20000.m3u8"
            },
            {
                "name": "VTV5",
                "logo": "https://s12811.cdn.mytvnet.vn/vimages/b5/5c/cc/c2/22/29/b5cc2-pvtv5hd-channel-unkn.png",
                "group": "VTV",
                "url": "https://vips-livecdn.fptplay.net/live/media/vtv5/live247-hls-avc/vtv5-avc1_5600000=10000-mp4a_131600=20000.m3u8",
                "headers": {
                    "User-Agent": "cvmedia/1.1.0"
                }
            },
            {
                "name": "VTV5 Tây Nam Bộ",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/maxresdefault.jpg",
                "group": "VTV",
                "url": "https://vips-livecdn.fptplay.net/live/media/vtv5tnb/live-hls-avc/vtv5tnb-avc1_4000000=10000-mp4a_131600=20000.m3u8"
            },
            {
                "name": "VTV5 Tây Nguyên",
                "logo": "https://s7730.cdn.mytvnet.vn/vimages/d4/46/61/1c/cf/f6/d461c-pvtv5tynguynhd-channel-unkn.png",
                "group": "VTV",
                "url": "https://vips-livecdn.fptplay.net/live/media/vtv5tn/live-hls-avc/vtv5tn-avc1_4000000=10000-mp4a_131600=20000.m3u8"
            },
            {
                "name": "VTV6",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/VTV6.png",
                "group": "VTV",
                "url": "https://vips-livecdn.fptplay.net/live/media/vtv6/live247-hls-avc/vtv6-avc1_5600000=10000-mp4a_131600=20000.m3u8"
            },
            {
                "name": "VTV7",
                "logo": "https://i.ytimg.com/vi/hWt5JN_B66Y/maxresdefault.jpg",
                "group": "VTV",
                "url": "https://vips-livecdn.fptplay.net/live/media/vtv7/live247-hls-avc/vtv7-avc1_5600000=10000-mp4a_131600=20000.m3u8"
            },
            {
                "name": "VTV8",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/vtv8.jpg",
                "group": "VTV",
                "url": "https://vips-livecdn.fptplay.net/live/media/vtv8/live-hls-avc/vtv8-avc1_4000000=10000-mp4a_131600=20000.m3u8"
            },
            {
                "name": "VTV9",
                "logo": "https://i.ytimg.com/vi/APl10jiVAlQ/maxresdefault.jpg",
                "group": "VTV",
                "url": "https://vips-livecdn.fptplay.net/live/media/vtv9/live247-hls-avc/vtv9-avc1_5600000=10000-mp4a_131600=20000.m3u8"
            },
            {
                "name": "VTV10",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/VTV10.png",
                "group": "VTV",
                "url": "https://vips-livecdn.fptplay.net/live/media/vtv10/live247-hls-avc/vtv10-avc1_5600000=10000-mp4a_131600=20000.m3u8"
            }
        ],
        "VTVcab": [
            {
                "name": "ON Vie Giải Trí",
                "logo": "https://i.ytimg.com/vi/fyT_xa-g-Pk/hq720.jpg",
                "group": "VTVcab",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=180",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "ON Phim Việt",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/ONPHIMVIET.png",
                "group": "VTVcab",
                "url": "https://vmttv.dpdns.org/tv360/?id=vtvcab-2-phim-viet-hd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "On Movies - You TV",
                "logo": "https://i.ytimg.com/vi/NZablQM-L9g/maxresdefault.jpg",
                "group": "VTVcab",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=181",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "ON E- Channel",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/onechannel.png",
                "group": "VTVcab",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=182",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "On O2TV",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/ono2tv.png",
                "group": "VTVcab",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=136",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "On BiBi",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/onbibi.png",
                "group": "VTVcab",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=178",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "ON Info TV",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/oninfotv.png",
                "group": "VTVcab",
                "url": "https://tpninosaga.duckdns.org/source/tv360.m3u8?id=189&token=NinoEra36",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "ON Cine",
                "logo": "https://i.ytimg.com/vi/rwhsuTvSXxo/maxresdefault.jpg",
                "group": "VTVcab",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=176",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "ON Style TV",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/onstyle.png",
                "group": "VTVcab",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=184",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "On Music",
                "logo": "https://img-zlr1.tv360.vn/image1/2023/07/20/10/1689822524259/0f3a4d1ebfaf_640_360.png",
                "group": "VTVcab",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=185",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "ON TRENDING TV",
                "logo": "https://i.ibb.co/k1ccQNr/vcab17.webp",
                "group": "VTVcab",
                "url": "https://tpninosaga.duckdns.org/source/tv360.m3u8?id=186&token=NinoEra36",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "ON Vie Dramas",
                "logo": "https://i.ytimg.com/vi/4SqDlPT8oEI/maxresdefault.jpg",
                "group": "VTVcab",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=177",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "ON V Family",
                "logo": "https://i.ibb.co/HHfL7Dq/cocab20.webp",
                "group": "VTVcab",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=187",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            },
            {
                "name": "On Kids",
                "logo": "https://assets-vtvcab.gviet.vn/images/v2/channel/20220613/2022061306/onkids5_1675158859.webp",
                "group": "VTVcab",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=179",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            },
            {
                "name": "On Life",
                "logo": "https://img-ali1.tv360.vn/image1/2023/07/19/09/1689732652862/f124f55c3587_640_360.png",
                "group": "VTVcab",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=188",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            },
            {
                "name": "On Golf",
                "logo": "https://img.lichphatsong.site/logo/on-golf.jpg",
                "group": "VTVcab",
                "url": "https://vmttv.dpdns.org/tv360/?id=vtvcab-23-golf-channel",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            }
        ],
        "SCTV": [
            {
                "name": "SCTV1",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/sctv1.png",
                "group": "SCTV",
                "url": "https://vmttv.dpdns.org/VTVGo/?sctv1"
            },
            {
                "name": "SCTV2 - TODAY TV",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/SCTV2TODAYTV.jpg",
                "group": "SCTV",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=201",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "SCTV3",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/sctv3.png",
                "group": "SCTV",
                "url": "https://vmttv.dpdns.org/VTVGo/?sctv3"
            },
            {
                "name": "SCTV4",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/sctv4.png",
                "group": "SCTV",
                "url": "https://vmttv.dpdns.org/VTVGo/?sctv4"
            },
            {
                "name": "SCTV5",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/SCTV5.jpg",
                "group": "SCTV",
                "url": "https://vmttv.dpdns.org/VTVGo/?sctv5"
            },
            {
                "name": "SCTV6",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/sctv6.png",
                "group": "SCTV",
                "url": "https://live.fptplay53.net/epzhd2/film360_vhls.smil/chunklist_b5000000.m3u8",
                "headers": {
                    "User-Agent": "VThanhTivi"
                }
            },
            {
                "name": "SCTV7",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/sctv7.webp",
                "group": "SCTV",
                "url": "https://vmttv.dpdns.org/VTVGo/?sctv7"
            },
            {
                "name": "SCTV8",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/sctv8.png",
                "group": "SCTV",
                "url": "https://vmttv.dpdns.org/VTVGo/?sctv8"
            },
            {
                "name": "SCTV9",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/SCTV9.png",
                "group": "SCTV",
                "url": "https://vmttv.dpdns.org/VTVGo/?sctv9"
            },
            {
                "name": "SCTV10",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/SCTV10.jpg",
                "group": "SCTV",
                "url": "https://vmttv.dpdns.org/VTVGo/?sctv10"
            },
            {
                "name": "SCTV11",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/sctv11.png",
                "group": "SCTV",
                "url": "https://vmttv.dpdns.org/VTVGo/?sctv11"
            },
            {
                "name": "SCTV12",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/sctv12.png",
                "group": "SCTV",
                "url": "https://vmttv.dpdns.org/VTVGo/?sctv12"
            },
            {
                "name": "SCTV13",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/sctv13.png",
                "group": "SCTV",
                "url": "https://vmttv.dpdns.org/VTVGo/?sctv13"
            },
            {
                "name": "SCTV14",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/sctv14.png",
                "group": "SCTV",
                "url": "https://vmttv.dpdns.org/VTVGo/?sctv14"
            },
            {
                "name": "SCTV15",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/SCTV15.png",
                "group": "SCTV",
                "url": "https://liveatmvng.vtvprime.vn/live/data8/SCTV15HD/Live_DASHDRM/SCTV15HD.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "SCTV16",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/sctv16.png",
                "group": "SCTV",
                "url": "https://vmttv.dpdns.org/VTVGo/?sctv16"
            },
            {
                "name": "SCTV17",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/SCTV17.png",
                "group": "SCTV",
                "url": "https://liveatmvng.vtvprime.vn/live/data8/SCTV17/Live_DASHDRM/SCTV17.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "SCTV18",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/sctv18.png",
                "group": "SCTV",
                "url": "https://vmttv.dpdns.org/VTVGo/?sctv18"
            },
            {
                "name": "SCTV19",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/sctv19.png",
                "group": "SCTV",
                "url": "https://vmttv.dpdns.org/VTVGo/?sctv19"
            },
            {
                "name": "SCTV20",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/SCTV20.png",
                "group": "SCTV",
                "url": "https://vmttv.dpdns.org/VTVGo/?sctv20"
            },
            {
                "name": "SCTV21 - Việt Nam Ký Ức",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/SCTV21.png",
                "group": "SCTV",
                "url": "https://vmttv.dpdns.org/VTVGo/?sctv21"
            },
            {
                "name": ":SCTV22",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/SCTV22.png",
                "group": "SCTV",
                "url": "https://liveatmvng.vtvprime.vn/live/data8/SCTV22/Live_DASHDRM/SCTV22.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "SCTV Phim Tổng Hợp",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/sctvpth.png",
                "group": "SCTV",
                "url": "https://vmttv.dpdns.org/VTVGo/?sctvphim"
            }
        ],
        "Unknown": [
            {
                "name": "",
                "logo": "",
                "group": "Unknown",
                "url": "https://livevlisctcdnw.seenow.vn/Live_DASHDRM1/BM1/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Radio Nhạc Vàng Xưa",
                "logo": "https://dongnhacvang.com/wp-content/uploads/2019/08/cropped-logo-nhac-vang-1-2.png",
                "group": "Unknown",
                "url": "https://stream.zeno.fm/x2z45v7d84zuv"
            }
        ],
        "📦| In The Box": [
            {
                "name": "Hollywood Classics",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/hollywoodclassic.png",
                "group": "📦| In The Box",
                "url": "https://livevlisctcdnw.seenow.vn/Live_DASHDRM1/HC/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Box Hits",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/boxhits.png",
                "group": "📦| In The Box",
                "url": "https://livevlisctcdnw.seenow.vn/mean/BOXHIT/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Music Box",
                "logo": "https://img-zlr1.tv360.vn/image1/2023/07/20/10/1689822939536/68d521f6938e_640_360.png",
                "group": "📦| In The Box",
                "url": "https://livevlisctcdnw.seenow.vn/livesnv2/MUSICBOX/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Woman",
                "logo": "https://img-zlr1.tv360.vn/image1/2020_09_23/1600822442611/f6b738c3d05a_640_360.png",
                "group": "📦| In The Box",
                "url": "https://livevlisctcdnw.seenow.vn/Live_DASHDRM1/WO/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            }
        ],
        "HTV": [
            {
                "name": "HTV1 - Đài PTTH Thành Phố Hồ Chí Minh",
                "logo": "https://s7771.cdn.mytvnet.vn/vimages/8c/ce/ee/e7/79/98/8cee7-phtv1hd-channel-unkn.png",
                "group": "HTV",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=190",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "HTV2 - Vie Channel",
                "logo": "https://s7768.cdn.mytvnet.vn/vimages/a0/07/73/39/9e/e6/a0739-phtv2hd-channel-unkn.png",
                "group": "HTV",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=191",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "HTV3 - Đài PTTH Thành Phố Hồ Chí Minh",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/HTV3.jpg",
                "group": "HTV",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=192",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "HTV4 - Đài PTTH Thành Phố Hồ Chí Minh",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/HTV4.jpg",
                "group": "HTV",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=9",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "HTV5 - B Channel",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/HTV5.jpg",
                "group": "HTV",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=151",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "HTV7 - Đài PTTH Thành Phố Hồ Chí Minh",
                "logo": "https://img-zlr1.tv360.vn/image1/2020_09_23/1600822381421/47d2615f6141_640_360.png",
                "group": "HTV",
                "url": "https://live.fptplay53.net/live/media/htv7/live247-hls-avc/htv7-avc1_5600000=10000-mp4a_131600=20000.m3u8"
            },
            {
                "name": "HTV9 - Đài PTTH Thành Phố Hồ Chí Minh",
                "logo": "https://img-zlr1.tv360.vn/image1/2020_09_23/1600822390705/a9fc59138d3b_640_360.png",
                "group": "HTV",
                "url": "https://live-a.fptplay53.net/live/media/htv9/live247-hls-avc/htv9-avc1_5600000=10000-mp4a_131600=20000.m3u8"
            },
            {
                "name": "HTV Thể Thao",
                "logo": "https://img-zlr1.tv360.vn/image1/2023/04/03/16/1680514594557/ab2557f0b015_640_360.png",
                "group": "HTV",
                "url": "https://live.fptplay53.net/live/media/htvthethao/live247-hls-avc/htvthethao-avc1_5600000=10000-mp4a_131600=20000.m3u8"
            },
            {
                "name": "HTVC Plus HD",
                "logo": "https://vietanhtv.id.vn/logo/htvcplus.png",
                "group": "HTV",
                "url": "https://live.fptplay53.net/epzhd1/htvcplus_vhls.smil/chunklist_b5000000.m3u8"
            }
        ],
        "HTVC": [
            {
                "name": "HTVC Thuần Việt",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/htvcthuanviet.png",
                "group": "HTVC",
                "url": "https://live.fptplay53.net/epzhd1/htvcthuanviethd_vhls.smil/chunklist.m3u8"
            },
            {
                "name": "HTVC Gia đình HD",
                "logo": "",
                "group": "HTVC",
                "url": "https://live.fptplay53.net/epzhd1/htvcgiadinh_vhls.smil/chunklist.m3u8"
            },
            {
                "name": "HTVC Phụ nữ HD",
                "logo": "https://img-zlr1.tv360.vn/image1/2020_09_23/1600823432136/86f5cc6afcf6_640_360.png",
                "group": "HTVC",
                "url": "https://live.fptplay53.net/epzhd1/htvcphunu_vhls.smil/chunklist.m3u8"
            },
            {
                "name": "HTVC Du lịch Cuộc sống HD",
                "logo": "https://img-zlr1.tv360.vn/image1/2020/12/25/08/1608860643587/bb01290ccde1_640_360.png",
                "group": "HTVC",
                "url": "https://live.fptplay53.net/epzhd1/htvcdulich_vhls.smil/chunklist_b5000000.m3u8"
            },
            {
                "name": "HTVC Ca nhạc HD",
                "logo": "https://img-zlr1.tv360.vn/image1/2020_09_23/1600823449894/0834e6a36f71_640_360.png",
                "group": "HTVC",
                "url": "https://live.fptplay53.net/epzhd1/htvcmusic_vhls.smil/chunklist.m3u8"
            }
        ],
        "🌐| Thiết yếu": [
            {
                "name": "ANTV HD",
                "logo": "https://img-zlr1.tv360.vn/image1/2020_09_23/1600822516608/b33963dc0df8_640_360.png",
                "group": "🌐| Thiết yếu",
                "url": "https://live.fptplay53.net/fnxhd2/anninhtv_vhls.smil/chunklist_b5000000.m3u8"
            },
            {
                "name": "QPVN HD",
                "logo": "https://i.ytimg.com/vi/sFLUmdwp0Z8/maxresdefault.jpg",
                "group": "🌐| Thiết yếu",
                "url": "https://live.fptplay53.net/fnxhd2/quocphongvnhd_vhls.smil/chunklist_b5000000.m3u8"
            }
        ],
        "Địa phương": [
            {
                "name": "DRT HD - Báo và PTTH Đắk Lắk",
                "logo": "https://img-zlr1.tv360.vn/image1/2025/06/30/11/1751256466336/bda77a407209_640_360.png",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=51",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "THP HD - Báo và PTTH Hải Phòng",
                "logo": "https://upload.wikimedia.org/wikipedia/vi/9/90/THP-Logo.png",
                "group": "Địa phương",
                "url": "https://live.fptplay53.net/live/media/haiphong/live-hls-avc/haiphong-avc1_4000000=10000-mp4a_131600=20000.m3u8"
            },
            {
                "name": "THP3 - Báo và PTTH Hải Phòng",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/THP3.png",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=59",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Cần Thơ 1 HD - Báo và PTTH Thành Phố Cần Thơ",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/CanTho1.png",
                "group": "Địa phương",
                "url": "https://live.canthotv.vn/live/tv/chunklist_w693005420.m3u8"
            },
            {
                "name": "Cần Thơ 2 HD - Báo và PTTH Thành Phố Cần Thơ",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/CanTho2.png",
                "group": "Địa phương",
                "url": "https://live.canthotv.vn/cs2/live.stream/chunklist_w1497265452.m3u8"
            },
            {
                "name": "Cần Thơ 3 HD - Báo và PTTH Thành Phố Cần Thơ",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/CanTho3.png",
                "group": "Địa phương",
                "url": "https://live.canthotv.vn/cs3/tv/chunklist_w1003748170.m3u8",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            },
            {
                "name": "STV HD - Báo và PTTH Sơn La",
                "logo": "https://media.sonlatv.vn/upload/files/image/Back-TH-1.jpg",
                "group": "Địa phương",
                "url": "https://cdn.sonlatv.vn/live/28595222e707a364251b8724717894baa46/chunklist.m3u8",
                "headers": {
                    "User-Agent": "VThanhTivi"
                }
            },
            {
                "name": "PTV HD - Báo và PTTH Phú Thọ",
                "logo": "https://img-zlr1.tv360.vn/image1/2023/05/16/02/168417957456/7016ca1be5fa_640_360.png",
                "group": "Địa phương",
                "url": "https://vmttv.dpdns.org/tv360/?id=phu-tho",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "ĐNNRTV1 - Báo và PTTH Đồng Nai",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/ĐNNRTV1HD.png",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=53",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "ĐNNRTV2 - Báo và PTTH Đồng Nai",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/ĐNNRTV2.png",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=255",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "ĐNNRTV3 - Báo và PTTH Đồng Nai",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/ĐNNRTV3.png",
                "group": "Địa phương",
                "url": "https://live.fptplay53.net/epzsd1/dongnai3_hls.smil/chunklist_b2500000.m3u8",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "H1 - Báo và PTTH Hà Nội",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/H1.jpg",
                "group": "Địa phương",
                "url": "https://live.fptplay53.net/fnxhd2/hanoitv1_vhls.smil/chunklist_b5000000.m3u8"
            },
            {
                "name": "H2 - Báo và PTTH Hà Nội",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/H2.jpg",
                "group": "Địa phương",
                "url": "https://live.fptplay53.net/fnxhd1/hntv2_vhls.smil/chunklist_b5000000.m3u8"
            },
            {
                "name": "TTV HD - Báo và PTTH Thanh Hóa",
                "logo": "https://img-zlr1.tv360.vn/image1/2020_09_23/1600821878406/58ff77e57117_640_360.png",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=89",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "QTV1 HD - Báo và PTTH Quảng Ninh",
                "logo": "https://media.baoquangninh.vn/upload/files/logo/QTV1.jpg",
                "group": "Địa phương",
                "url": "https://live.baoquangninh.vn/qtvlive/tv1live.m3u8"
            },
            {
                "name": "QTV3 HD - Báo và PTTH Quảng Ninh",
                "logo": "https://i.ytimg.com/vi/cTNt-U1akXw/hq720.jpg",
                "group": "Địa phương",
                "url": "https://live.baoquangninh.vn/qtvlive/tv3live.m3u8"
            },
            {
                "name": "THVL1 - Báo và PTTH Vĩnh Long",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/THVL1.webp",
                "group": "Địa phương",
                "url": "https://live.fptplay53.net/live/media/vinhlong1/live247-hls-avc/vinhlong1-avc1_3800000=10000-mp4a_131600=20000.m3u8"
            },
            {
                "name": "THVL2 - Báo và PTTH Vĩnh Long",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/THVL2.webp",
                "group": "Địa phương",
                "url": "https://live.fptplay53.net/live/media/vinhlong2/live247-hls-avc/vinhlong2-avc1_3800000=10000-mp4a_131600=20000.m3u8"
            },
            {
                "name": "THVL3 - Báo và PTTH Vĩnh Long",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/THVL3.webp",
                "group": "Địa phương",
                "url": "https://vips-livecdn.fptplay.net/live/media/vinhlong3/live247-hls-avc/vinhlong3-avc1_5600000=10000-mp4a_131600=20000.m3u8"
            },
            {
                "name": "THVL4 - Báo và PTTH Vĩnh Long",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/THVL4.webp",
                "group": "Địa phương",
                "url": "https://live.fptplay53.net/epzhd2/vinhlong4hd_vhls.smil/chunklist_b5000000.m3u8",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            },
            {
                "name": "THVL5 - Báo và PTTH Vĩnh Long",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/THVL5.webp",
                "group": "Địa phương",
                "url": "https://live.fptplay53.net/epzhd2/vinhlong5hd_vhls.smil/chunklist_b5000000.m3u8"
            },
            {
                "name": "ATV2 | Báo và PTTH An Giang",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/ATV2.jpg",
                "group": "Địa phương",
                "url": "https://live.fptplay53.net/epzhd2/angiang02hd_vhls.smil/chunklist_b5000000.m3u8"
            },
            {
                "name": "NBTV - Báo và PTTH Ninh Bình",
                "logo": "https://img-zlr1.tv360.vn/image1/2024/10/07/16/1728293640310/9aea44bf0f8d_640_360.png",
                "group": "Địa phương",
                "url": "https://live.mediatech.vn/live/28597f8fd7ea5064d0f84ab00b3699dfd86/chunklist.m3u8"
            },
            {
                "name": "NTV - Báo và PTTH Nghệ An",
                "logo": "https://img-zlr1.tv360.vn/image1/2020_09_23/1600821989411/75bfb004e210_640_360.png",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=74",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "CTV HD - Báo và PTTH Cà Mau",
                "logo": "https://i.ytimg.com/vi/ESIlLqXKqyM/maxresdefault.jpg",
                "group": "Địa phương",
                "url": "https://live.fptplay53.net/epzhd2/camauhd_vhls.smil/chunklist_b5000000.m3u8"
            },
            {
                "name": "GTV - Báo và PTTH Gia Lai",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/GTVGIALAI.png",
                "group": "Địa phương",
                "url": "https://vmttv.dpdns.org/tv360/?id=gia-lai",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "KTV HD - Báo và PTTH Khánh Hòa",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/KTV_KhanhHoa.png",
                "group": "Địa phương",
                "url": "https://vmttv.dpdns.org/tv360/?id=khanh-hoa",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Huế TV - Báo và PTTH Huế",
                "logo": "https://i.imgur.com/q5MBibm.png",
                "group": "Địa phương",
                "url": "https://live.huetv.com.vn/TRT-Online/chunklist.m3u8"
            },
            {
                "name": "Tây Ninh TV - Báo và PTTH Tây Ninh",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/TayNinhTV.jpg",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=72",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "THĐT1 HD - Báo và PTTH Đồng Tháp",
                "logo": "https://img-zlr1.tv360.vn/image1/2024/10/07/16/1728292788373/2f4bec83df66_640_360.png",
                "group": "Địa phương",
                "url": "https://live.fptplay53.net/epzhd2/dongthap01_vhls.smil/chunklist_b5000000.m3u8"
            },
            {
                "name": "THĐT2 - Báo và PTTH Đồng Tháp",
                "logo": "https://images.fptplay53.net/media/channels/icon_channel_mien-tay-thdt2_165666993738.png",
                "group": "Địa phương",
                "url": "https://live.fptplay53.net/epzhd2/mientaythdt02_vhls.smil/chunklist_b5000000.m3u8"
            },
            {
                "name": "LTV2 HD - Báo và PTTH Lâm Đồng",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/LTV2.jpg",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=45",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "ĐNRT1 - Báo và PTTH Đà Nẵng",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/ĐNRT1.png",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=49",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "ĐNRT2 - Báo và PTTH Đà Nẵng",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/DNRT2_logo.png",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=80",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "ATV1 - Báo và PTTH An Giang",
                "logo": "https://angiangtv.vn/wp-content/uploads/2025/06/H4.png",
                "group": "Địa phương",
                "url": "https://tv.angiangtv.vn/live/kgtv/kgtv.m3u8"
            },
            {
                "name": "ATV3 - Báo và PTTH An Giang",
                "logo": "https://angiangtv.vn/wp-content/uploads/2025/06/H5.png",
                "group": "Địa phương",
                "url": "https://tv.angiangtv.vn/live/kgtv1/kgtv1.m3u8"
            },
            {
                "name": "LSTV HD - Báo và PTTH Lạng Sơn",
                "logo": "https://langsontv.vn/templates/frontend/lstv/Assets/img/video_bg.png",
                "group": "Địa phương",
                "url": "https://stream.langsontv.vn/live/285c78da0c246524c90917842f8de03bd21/chunklist.m3u8"
            },
            {
                "name": "QTTV - Báo và PTTH Quảng Trị",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/QTTV.jpg",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=83",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "BHTTV - Báo và PTTH Hà Tĩnh",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/BHTTV.webp",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=58",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "BTV - Báo và PTTH Bắc Ninh",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/BTVBACNINH.jpg",
                "group": "Địa phương",
                "url": "https://vmttv.dpdns.org/tv360/?id=bac-ninh",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "CRTV HD - Báo Cao Bằng",
                "logo": "https://img-zlr1.tv360.vn/image1/2024/10/07/16/1728292499129/aeb3499f5824_640_360.png",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=48",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "HYTV HD - Báo và PTTH Hưng Yên",
                "logo": "https://hungyentv.vn/templates/frontend/hytv/Assets/img/truyenhinh.jpg",
                "group": "Địa phương",
                "url": "https://vmttv.dpdns.org/tv360/?id=hung-yen",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "LTV - Báo Lai Châu",
                "logo": "https://images.fptplay53.net/media/channels/icon_channel_lai-chau_165649245279.png",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=68",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "KTV1 HD - Báo và PTTH Khánh Hòa",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/KTV1_KhanhHoa.png",
                "group": "Địa phương",
                "url": "https://vmttv.dpdns.org/tv360/?id=khanh-hoa-1",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "QNgTV1 - Báo và PTTH Quảng Ngãi",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/QNgTV1_QuangNgai.png",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=81",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "QNgTV2 - Báo và PTTH Quảng Ngãi",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/QNgTV2_QuangNgai.png",
                "group": "Địa phương",
                "url": "https://tv.vietanhtv.top/vieon/vieon.php?id=kon-tum-1",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "TTV HD - Báo và PTTH Tuyên Quang",
                "logo": "https://img-zlr1.tv360.vn/image1/2023/05/10/03/1683663305895/0f3f1e5bd284_640_360.png",
                "group": "Địa phương",
                "url": "https://vmttv.dpdns.org/tv360/?id=tuyen-quang",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "TN - Báo và PTTH Thái Nguyên",
                "logo": "https://img-zlr1.tv360.vn/image1/2025/07/01/07/1751329966912/3ddadef93c24_640_360.png",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=88",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "ĐTV HD - Báo Điện Biên Phủ",
                "logo": "https://img-zlr1.tv360.vn/image1/2020_09_23/1600823593760/3a9a9e608e8d_640_360.png",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=52",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "THLC HD - Báo và PTTH Lào Cai",
                "logo": "https://lichphatsongtivi.com/storage/images/thumbnails/lich-phat-song-thlc.png",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=71",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "LTV1 HD - Báo và PTTH Lâm Đồng",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/LTV1.jpg",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=69",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "HiTV",
                "logo": "https://img-zlr1.tv360.vn/image1/2020_09_23/1600823412691/61627b84a612_640_360.png",
                "group": "Địa phương",
                "url": "https://vmttv.dpdns.org/tv360/?id=hitv",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "YouTV",
                "logo": "https://img-ali1.tv360.vn/image1/2020_09_23/1600823396313/7b474bf7bbce_640_360.png",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=31",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            }
        ],
        "Quốc Tế": [
            {
                "name": "HBO",
                "logo": "https://i.pinimg.com/originals/8b/02/00/8b020050690f955ccb306cdf51324aea.png",
                "group": "Quốc Tế",
                "url": "https://s2129134.cdn.mytvnet.vn/pkg20/live_dzones/hbo.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Asian Food Network",
                "logo": "https://i.vimeocdn.com/video/852785228-36403e3d29153c02a4acfcf0ca4182b0be0bef3e5b43355eafc33614ee972a9b-d?f=webp",
                "group": "Quốc Tế",
                "url": "https://live.fptplay53.net/fnxhd2/afchd_vhls.smil/chunklist_b5000000.m3u8",
                "headers": {
                    "User-Agent": "VThanhTivi"
                }
            },
            {
                "name": "Cinemax HD",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/cinemax.png",
                "group": "Quốc Tế",
                "url": "https://s2129134.cdn.mytvnet.vn/pkg20/live_dzones/max.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Cinema World",
                "logo": "https://www.voilah.sg/wp-content/uploads/2020/04/cinema-world-2.png",
                "group": "Quốc Tế",
                "url": "https://s2129134.cdn.mytvnet.vn/pkg20/live_dzones/cinemaworld.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Cartoonito",
                "logo": "https://1000logos.net/wp-content/uploads/2023/10/Cartoonito-Logo.jpg",
                "group": "Quốc Tế",
                "url": "https://s2129134.cdn.mytvnet.vn/pkg20/live_dzones/boomerang.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Cartoon Network HD",
                "logo": "https://freight.cargo.site/w/1200/i/3cf72163d993c4d87263e6d4990ec4ccdd1e14b09ce89e6e35dee1de83ef4985/CN.jpg",
                "group": "Quốc Tế",
                "url": "https://s2129134.cdn.mytvnet.vn/pkg20/live_dzones/cn.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "BabyTV",
                "logo": "https://www.babytv.com/app/uploads/2019/12/LogoBabyTV-2019.png",
                "group": "Quốc Tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=960054&extension=ts&play_token=qpvBSWKfyz"
            },
            {
                "name": "Dreamworks",
                "logo": "https://s7266.cdn.mytvnet.vn/vimages/de/eb/ba/a7/7e/ee/deba7-pdreamworkshd-channel-unkn.png",
                "group": "Quốc Tế",
                "url": "https://s2129134.cdn.mytvnet.vn/pkg20/live_dzones/dreamwork.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "BBC Earth",
                "logo": "https://i.ytimg.com/vi/0jFG4yuzMRo/maxresdefault.jpg",
                "group": "Quốc Tế",
                "url": "https://s7771.cdn.mytvnet.vn/pkg20/live_dzones/bbcearth.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "BBC Lifestyle",
                "logo": "https://images.now-tv.com/shares/channelPreview/img/en_hk/color/ch502_425_305",
                "group": "Quốc Tế",
                "url": "https://s7770.cdn.mytvnet.vn/pkg20/live_dzones/bbclifestyle.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "BBC Cbeebies",
                "logo": "https://s72140.cdn.mytvnet.vn/vimages/7d/d5/58/8c/ce/ea/7d58c-pcbeebieshd-channel-unkn.png",
                "group": "Quốc Tế",
                "url": "https://s2129134.cdn.mytvnet.vn/pkg20/live_dzones/cbb.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "BBC World News",
                "logo": "https://i.ytimg.com/vi/jL2fsQB9J-g/maxresdefault.jpg",
                "group": "Quốc Tế",
                "url": "https://s7771.cdn.mytvnet.vn/pkg20/live_dzones/bbcworldnews.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Arirang",
                "logo": "https://i.ytimg.com/vi/ZqVyukYe4YM/hq720.jpg",
                "group": "Quốc Tế",
                "url": "https://live.fptplay53.net/fnxhd1/airanghd_vhls.smil/chunklist_b5000000.m3u8"
            },
            {
                "name": "Bloomberg",
                "logo": "https://i.imgur.com/rxFZgIK.png",
                "group": "Quốc Tế",
                "url": "https://s2129134.cdn.mytvnet.vn/pkg20/live_dzones/bloomberg.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "CNBC",
                "logo": "https://mir-s3-cdn-cf.behance.net/project_modules/max_1200/30b1d744249569.56076e09dd31e.png",
                "group": "Quốc Tế",
                "url": "https://live.fptplay53.net/fnxhd1/cnbchd_vhls.smil/chunklist_b5000000.m3u8"
            },
            {
                "name": "CNN",
                "logo": "https://deadline.com/wp-content/uploads/2020/09/CNN-Logo.jpg",
                "group": "Quốc Tế",
                "url": "https://s7771.cdn.mytvnet.vn/pkg20/live_dzones/cnn.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "CNA",
                "logo": "https://onecms-res.cloudinary.com/image/upload/v1673978069/mediacorp/corporate/inline-images/CNA__370x180.jpg",
                "group": "Quốc Tế",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=112",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "CGTN",
                "logo": "https://i.ytimg.com/vi/twB_6GV5AM8/hq720.jpg",
                "group": "Quốc Tế",
                "url": "https://english-livebkali.cgtn.com/live/encgtn_0.m3u8"
            },
            {
                "name": "CGTN Documentary",
                "logo": "https://i.ytimg.com/vi/QbB9p0LDAyE/maxresdefault.jpg",
                "group": "Quốc Tế",
                "url": "https://english-livebkali.cgtn.com/live/doccgtn_0.m3u8"
            },
            {
                "name": "TV5Monde",
                "logo": "https://information.tv5monde.com/sites/tv5-info/files/styles/entete/public/2023-11/tv5monde_logo.jpg",
                "group": "Quốc Tế",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=9852",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "DW",
                "logo": "https://i.ytimg.com/vi/puzK9XqJ6-Y/hq720.jpg",
                "group": "Quốc Tế",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=109",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Da Vinci HD",
                "logo": "https://images.fptplay53.net/media/channels/icon_channel_da-vinci-learning_165655659384.png",
                "group": "Quốc Tế",
                "url": "https://live.fptplay53.net/fnxhd2/davincihd_vhls.smil/chunklist_b5000000.m3u8",
                "headers": {
                    "User-Agent": "VThanhTivi"
                }
            },
            {
                "name": "France 24",
                "logo": "https://m.media-amazon.com/images/I/81oryzEMf-L.png",
                "group": "Quốc Tế",
                "url": "https://live.france24.com/hls/live/2037218/F24_EN_HI_HLS/master_5000.m3u8"
            },
            {
                "name": "KBS World",
                "logo": "https://img.hplus.com.vn/728x409/banner/2018/06/05/654179-KBS.png",
                "group": "Quốc Tế",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=213",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "NHK World",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/nhkworld.png",
                "group": "Quốc Tế",
                "url": "https://live.fptplay53.net/fnxhd2/nhkworld_vhls.smil/chunklist_b5000000.m3u8"
            },
            {
                "name": "Al Jazeera English",
                "logo": "https://upload.wikimedia.org/wikipedia/en/thumb/f/f2/Aljazeera_eng.svg/1280px-Aljazeera_eng.svg.png",
                "group": "Quốc Tế",
                "url": "https://live-hls-web-aje-gcp.thehlive.com/AJE/01.m3u8"
            },
            {
                "name": "TRT World",
                "logo": "https://mir-s3-cdn-cf.behance.net/project_modules/max_1200/425e1955860511.59ae62ac642ba.png",
                "group": "Quốc Tế",
                "url": "https://tv-trtworld.medya.trt.com.tr/master_1080.m3u8"
            },
            {
                "name": "Animal Planet",
                "logo": "https://vnepg.site/logos/143.png",
                "group": "Quốc Tế",
                "url": "https://s2129134.cdn.mytvnet.vn/pkg20/live_dzones/ap.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Discovery",
                "logo": "https://s72140.cdn.mytvnet.vn/vimages/c7/7f/fc/c6/69/9b/c7fc6-pdiscoveryhd-channel-unkn.png",
                "group": "Quốc Tế",
                "url": "https://s7770.cdn.mytvnet.vn/pkg20/live_dzones/dsc.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Discovery Asia",
                "logo": "https://astromedia.com.my/wp-content/uploads/2024/01/Discovery-Asia.png",
                "group": "Quốc Tế",
                "url": "https://s2129134.cdn.mytvnet.vn/pkg20/live_dzones/dscasia.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "AXN HD",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/axn.png",
                "group": "Quốc Tế",
                "url": "https://s7771.cdn.mytvnet.vn/pkg20/live_dzones/axn.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Outdoor Channel",
                "logo": "https://images.fptplay53.net/media/channels/icon_channel_outdoor-channel_165649323545.png",
                "group": "Quốc Tế",
                "url": "https://live.fptplay53.net/epzhd2/outdoorfhd_vhls.smil/chunklist_b5000000.m3u8",
                "headers": {
                    "User-Agent": "VThanhTivi"
                }
            },
            {
                "name": "History HD",
                "logo": "https://img-zlr1.tv360.vn/image1/2024/06/03/22/1717427367441/869de47c9504_640_360.png",
                "group": "Quốc Tế",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=9856",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "DMAX",
                "logo": "https://i.imgur.com/vHmt91V.png",
                "group": "Quốc Tế",
                "url": "https://s2129134.cdn.mytvnet.vn/pkg20/live_dzones/dmax.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "ABC Australia",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/abcaustralia.png",
                "group": "Quốc Tế",
                "url": "https://s935.cdn.mytvnet.vn/pkg20/live_dzones/aplus.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Fashion TV",
                "logo": "https://m.media-amazon.com/images/I/91B05VQC2kL.png",
                "group": "Quốc Tế",
                "url": "https://s2129134.cdn.mytvnet.vn/pkg20/live_dzones/ftv.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "KIX HD",
                "logo": "https://static.wikia.nocookie.net/logos/images/2/26/KIX.png/revision/latest/scale-to-width-down/1200?cb=20211017094335&path-prefix=vi",
                "group": "Quốc Tế",
                "url": "https://live.fptplay53.net/fnxhd2/kixhd_vhls.smil/chunklist_b5000000.m3u8",
                "headers": {
                    "User-Agent": "VThanhTivi"
                }
            },
            {
                "name": "TLC",
                "logo": "https://upload.wikimedia.org/wikipedia/commons/thumb/7/74/TLC_Logo.svg/1280px-TLC_Logo.svg.png",
                "group": "Quốc Tế",
                "url": "https://s129135.cdn.mytvnet.vn/pkg20/live_dzones/tlc.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Warner TV",
                "logo": "https://s7774.cdn.mytvnet.vn/vimages/6b/ba/a3/36/60/0a/6ba36-pwarnerhd-channel-unkn.png",
                "group": "Quốc Tế",
                "url": "https://s2129134.cdn.mytvnet.vn/pkg20/live_dzones/wtv.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Filmbox",
                "logo": "https://play-lh.googleusercontent.com/4IkIBkIFApQMYml2sW7XAV21mye06E_X5HssA-WsCRYBHIxWP5BQFzq79t0P5T8MrVs",
                "group": "Quốc Tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=1084668&extension=ts&play_token=onuPSPIV6o"
            },
            {
                "name": "HGTV",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/hgtv.png",
                "group": "Quốc Tế",
                "url": "https://liveh34.vtvprime.vn/hls/HGTV/03.m3u8"
            }
        ],
        "Radio": [
            {
                "name": "VOV1",
                "logo": "https://admin.vov.gov.vn/UploadFolder/KhoTin/Images/UploadFolder/VOVVN/Images/sites/default/files/2024-02/vov1.jpg",
                "group": "Radio",
                "url": "https://audio-lss.vov.vn/han/live/vov1/audio/haudio-eng.m3u8"
            },
            {
                "name": "VOV2",
                "logo": "https://vov2.vov.vn/themes/custom/vov_news/logo.png",
                "group": "Radio",
                "url": "https://audio-lss.vov.vn/han/live/vov2/audio/haudio-eng.m3u8"
            },
            {
                "name": "VOV3",
                "logo": "https://vov3.vov.vn/sites/default/files/styles/front_medium/public/2021-12/Logo%20VOV3%20800x600%20edit.jpg",
                "group": "Radio",
                "url": "https://audio-lss.vov.vn/han/live/vov3/audio/haudio-eng.m3u8"
            },
            {
                "name": "VOV5",
                "logo": "https://foxxradio.com/upload/vi/1671788035.png.webp",
                "group": "Radio",
                "url": "https://str.vov.gov.vn/vovlive/vov5.sdp_aac/playlist.m3u8"
            },
            {
                "name": "VOV Giao thông Hà Nội",
                "logo": "https://foxxradio.com/upload/vi/1671787624.png.webp",
                "group": "Radio",
                "url": "https://str.vov.gov.vn/vovlive/vovGTHN.sdp_aac/chunklist_w601606653.m3u8"
            },
            {
                "name": "VOV Giao thông Hồ Chí Minh",
                "logo": "https://foxxradio.com/upload/vi/1671787823.png.webp",
                "group": "Radio",
                "url": "https://str.vov.gov.vn/vovlive/vovGTHCM.sdp_aac/chunklist_w1213978008.m3u8"
            },
            {
                "name": "VOH FM 99.9Mhz",
                "logo": "https://ravimedia.vn/wp-content/uploads/2021/06/ravimedia-voh99.9mhz.jpg",
                "group": "Radio",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=10037",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "VOH FM 95.6Mhz",
                "logo": "https://cdn.instant.audio/images/logos/vietnamradio-org/voh-fm-95-6.png",
                "group": "Radio",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=10039",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "VOH FM 87.7Mhz",
                "logo": "https://image.voh.com.vn/voh/image/2023/12/06/voh-fm877-512x512-110237.png",
                "group": "Radio",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=10038",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "VOH AM 610Khz",
                "logo": "https://image.voh.com.vn/voh/image/2023/12/06/voh-am610-512x512-104316.png",
                "group": "Radio",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=10036",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "VOH FM 92 - 92.5 MHz",
                "logo": "https://image.voh.com.vn/voh/image/2025/11/17/92-5-3-104929.png",
                "group": "Radio",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=10040",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Bắc Ninh",
                "logo": "https://bacninhtv.vn/templates/frontend/bgtv/Assets/img/v3/btv_bg_video.jpg",
                "group": "Radio",
                "url": "https://live.mediatech.vn/live/285acd5e43b501e4c21b0af4e55810625c8/chunklist.m3u8"
            },
            {
                "name": "Cà Mau",
                "logo": "http://118.69.199.136/wp-content/uploads/2014/01/radio_online.jpg",
                "group": "Radio",
                "url": "http://tv.ctvcamau.vn/live/radio/radio.m3u8"
            },
            {
                "name": "Cần Thơ Radio 1",
                "logo": "https://canthoplus.vn/storage/channels/9b7858d5-ff44-43b3-94ab-e4d66a54f1bd.png",
                "group": "Radio",
                "url": "https://live.canthotv.vn/live/radio/chunklist_w1780522487.m3u8"
            },
            {
                "name": "Cần Thơ Radio 2",
                "logo": "https://canthoplus.vn/storage/channels/d18742e3-5735-43ea-9001-77678b4ef751.png",
                "group": "Radio",
                "url": "https://live.canthotv.vn/live/radiocs2/chunklist_w790093430.m3u8"
            },
            {
                "name": "Đà Nẵng",
                "logo": "https://www.danangtv.vn/Uploads/Media/Images/101220211598radio.png",
                "group": "Radio",
                "url": "https://live.mediatech.vn/live/2858a998b1c7fbf4522accd5554588ceae3/chunklist.m3u8"
            },
            {
                "name": "Đắk Lắk",
                "logo": "https://static.wikia.nocookie.net/logos/images/f/f3/Logo_DRT_FM_92%2C4MHz_%26_FM_94%2C7MHz.png/revision/latest/scale-to-width-down/1082?cb=20220613173357&path-prefix=vi",
                "group": "Radio",
                "url": "https://cdn.drt.vn/live/285054c4567dea54b3fb14bfd60d61230b5/chunklist.m3u8"
            },
            {
                "name": "Đồng Nai",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/dongnaifm.png",
                "group": "Radio",
                "url": "http://118.107.85.5:1935/radio/dongnai_aac/playlist.m3u8"
            },
            {
                "name": "Đồng Tháp",
                "logo": "https://image.voh.com.vn/voh/image/2023/12/27/thumbnail-dai-dong-thap-app-102539.jpg",
                "group": "Radio",
                "url": "https://64d0d74b76158.streamlock.net/THDTR/thdtradio/chunklist.m3u8"
            },
            {
                "name": "Hà Nội FM 90",
                "logo": "https://image.voh.com.vn/voh/image/2024/03/08/dai-ha-noi-5_90mhz---3-01-111825.jpg",
                "group": "Radio",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=9905",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Hà Nội FM 96",
                "logo": "https://image.voh.com.vn/voh/image/2024/03/08/dai-ha-noi-5_96mhz--3-01-111727.jpg?w=450&h=270",
                "group": "Radio",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=9906",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Hà Tĩnh",
                "logo": "https://hatinhtv.vn/Media/FileManager/thumbbht/2cc3530c808035de6c91.jpg",
                "group": "Radio",
                "url": "https://wse.hatinhtv.net/radio/voht/playlist.m3u8"
            },
            {
                "name": "Hưng Yên",
                "logo": "http://hungyentv.vn//templates/frontend/hytv/Assets/img/backgroud-radio.jpg",
                "group": "Radio",
                "url": "https://live.mediatech.vn/live/285b6e443bc30734725a940da8b0629655b/chunklist.m3u8"
            },
            {
                "name": "An Giang FM 99,4 Mhz",
                "logo": "https://angiangtv.vn/wp-content/uploads/2025/06/H6.png",
                "group": "Radio",
                "url": "https://tv.angiangtv.vn/live/kgaudio/kgaudio.m3u8",
                "headers": {
                    "User-Agent": "VThanhTivi"
                }
            },
            {
                "name": "An Giang FM 93.1 Mhz",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/ATVFM93.1%20MHZ.jpg",
                "group": "Radio",
                "url": "https://tv.angiangtv.vn/live/kgtv3/kgtv3.m3u8"
            },
            {
                "name": "Lâm Đồng",
                "logo": "https://lichphatsongtivi.com/storage/images/thumbnails/lich-phat-song-radio-lam-dong.png",
                "group": "Radio",
                "url": "https://cloudstreamthdn.tek4tv.vn/audio/daknong_radio/chunklist_w1535814517.m3u8"
            },
            {
                "name": "Lạng Sơn",
                "logo": "http://langsontv.vn/templates/frontend/lstv/Assets/img/radio_bg.png",
                "group": "Radio",
                "url": "https://stream.langsontv.vn/live/285dabcfc94f52b458688fe7f601524816e/chunklist.m3u8"
            },
            {
                "name": "Ninh Bình",
                "logo": "https://nbtv.vn/templates/frontend/nbtv/Assets/img/audio_bg.jpg",
                "group": "Radio",
                "url": "https://live.mediatech.vn/live/285391a08f01f83458793b293c5e9517265/chunklist.m3u8"
            },
            {
                "name": "QNR1 - Quảng Ninh",
                "logo": "https://media.baoquangninh.vn/upload/files/logo/logotrangchu4.png",
                "group": "Radio",
                "url": "http://103.90.220.236/qtvlive/qnr1.m3u8"
            },
            {
                "name": "QNR2 - Quảng Ninh",
                "logo": "https://media.baoquangninh.vn/upload/files/logo/logotrangchu3.png",
                "group": "Radio",
                "url": "http://103.90.220.236/qtvlive/qnr2.m3u8"
            },
            {
                "name": "Sơn La",
                "logo": "https://media.sonlatv.vn/upload/files/image/Back-PT.jpg",
                "group": "Radio",
                "url": "https://cdn.sonlatv.vn/live/285bfb76d0d7a3c4615b853fe7a698e150c/chunklist.m3u8"
            },
            {
                "name": "Thái Nguyên",
                "logo": "http://esb.thainguyentv.vn/upload/group/news//hytvgo_5ff2dd1ed1b81.jpg",
                "group": "Radio",
                "url": "https://radio.thainguyentv.vn/hls/livestream.m3u8"
            },
            {
                "name": "Tây Ninh",
                "logo": "https://w.ladicdn.com/s450x400/5ec394fc3354ff26568e1124/logo-fm1031mhz-20211008162127.png",
                "group": "Radio",
                "url": "https://live-hq.evgcdn.net/live/2851dd3d9016ac74d84b0c4a7a659f76891/chunklist.m3u8"
            },
            {
                "name": "M Radio Việt Nam",
                "logo": "https://proxy.zeno.fm/content/stations/agxzfnplbm8tc3RhdHNyMgsSCkF1dGhDbGllbnQYgICQ2ciKiAoMCxIOU3RhdGlvblByb2ZpbGUYgICQucnHqwsMogEEemVubw/image/",
                "group": "Radio",
                "url": "https://stream.zeno.fm/4q7y9hvkp2zuv"
            },
            {
                "name": "Cải Lương Việt Nam",
                "logo": "https://proxy.zeno.fm/content/stations/agxzfnplbm8tc3RhdHNyMgsSCkF1dGhDbGllbnQYgICQ2ciKiAoMCxIOU3RhdGlvblByb2ZpbGUYgIDQoL-YpAoMogEEemVubw/image/",
                "group": "Radio",
                "url": "https://stream.zeno.fm/0trm6wrnga0uv"
            },
            {
                "name": "Radio DJ",
                "logo": "https://proxy.zeno.fm/content/stations/agxzfnplbm8tc3RhdHNyMgsSCkF1dGhDbGllbnQYgICQ2ciKiAoMCxIOU3RhdGlvblByb2ZpbGUYgIDQidjS_wkMogEEemVubw/image/",
                "group": "Radio",
                "url": "https://stream.zeno.fm/ehbutdfccm0uv"
            },
            {
                "name": "Radio Phật Giáo",
                "logo": "https://proxy.zeno.fm/content/stations/agxzfnplbm8tc3RhdHNyMgsSCkF1dGhDbGllbnQYgICQ2ciKiAoMCxIOU3RhdGlvblByb2ZpbGUYgIDQiavcsgsMogEEemVubw/image/",
                "group": "Radio",
                "url": "https://stream.zeno.fm/8456uy0bcm0uv"
            },
            {
                "name": "Radio Nhạc Dân Ca",
                "logo": "https://proxy.zeno.fm/content/stations/agxzfnplbm8tc3RhdHNyMgsSCkF1dGhDbGllbnQYgICQ2ciKiAoMCxIOU3RhdGlvblByb2ZpbGUYgICw0ILTsQoMogEEemVubw/image/",
                "group": "Radio",
                "url": "https://stream.zeno.fm/a2dbs2tq1p8uv"
            }
        ],
        "🇬🇧 UK Radio": [
            {
                "name": "Heart FM UK",
                "logo": "https://ukradiolive.com/public/uploads/radio_img/heart-london/fb_cover.jpg",
                "group": "🇬🇧 UK Radio",
                "url": "https://media-ssl.musicradio.com/HeartUK"
            },
            {
                "name": "Capital Radio UK",
                "logo": "https://www.globalplayer.com/assets/track-placeholders/capital.jpg",
                "group": "🇬🇧 UK Radio",
                "url": "https://media-ssl.musicradio.com/CapitalUK"
            }
        ],
        "Israel": [
            {
                "name": "Virgin Media Three",
                "logo": "https://upload.wikimedia.org/wikipedia/en/thumb/2/2f/Virgin_Media_Three_logo_2018.svg/3840px-Virgin_Media_Three_logo_2018.svg.png",
                "group": "Israel",
                "url": "https://d3n2r2x6pixas4.cloudfront.net/out/v1/426d7a9e942b4f64917d66940bd3b147/index.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Virgin Media Four",
                "logo": "https://i.ytimg.com/vi/QZZijZXNeqo/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLC-WbMQHFRNT0NZEmZ7Wngm4na2TQ",
                "group": "Israel",
                "url": "https://d1o5wc5bjvzqoa.cloudfront.net/out/v1/bb744b243afb44eabcc56d002c36cafd/index.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            }
        ],
        "🇰🇷| Hàn Quốc": [
            {
                "name": "CJB SBS",
                "logo": "https://static.wikia.nocookie.net/logos/images/3/3f/CJB.jpg/revision/latest?cb=20200224093248&path-prefix=ko",
                "group": "🇰🇷| Hàn Quốc",
                "url": "http://1.222.207.80:1935/live/cjbtv/playlist.m3u8"
            },
            {
                "name": "JTV SBS",
                "logo": "https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Jtv_logo.svg/250px-Jtv_logo.svg.png?_=20220328012951",
                "group": "🇰🇷| Hàn Quốc",
                "url": "http://61.85.197.53:1935/jtv_live/myStream/chunklist_w1542137203.m3u8"
            },
            {
                "name": "G1 SBS",
                "logo": "https://upload.wikimedia.org/wikipedia/commons/thumb/3/38/G1_broadcasting_logo.svg/250px-G1_broadcasting_logo.svg.png",
                "group": "🇰🇷| Hàn Quốc",
                "url": "http://61.82.49.4:1935/live/_definst_/tv.stream/playlist.m3u8"
            },
            {
                "name": "MBC",
                "logo": "https://img.imbc.com/commons/2018/image/comm2018noti/meta_mbc.png",
                "group": "🇰🇷| Hàn Quốc",
                "url": "https://ns1.tjmbc.co.kr/live/myStream.sdp/chunklist_w1392208922.m3u8"
            },
            {
                "name": "MBC Chuncheon",
                "logo": "https://upload.wikimedia.org/wikipedia/commons/thumb/5/55/%EC%B6%98%EC%B2%9C_MBC.svg/3840px-%EC%B6%98%EC%B2%9C_MBC.svg.png",
                "group": "🇰🇷| Hàn Quốc",
                "url": "https://stream.chmbc.co.kr/TV/myStream/playlist.m3u8"
            },
            {
                "name": "MBC Chungbuk",
                "logo": "https://i.namu.wiki/i/_ok2k1eWuOVMUOzJvkKfMho8XkxLgcH5iEsIGNhQzDp4aRF14b5Xmix5m89ilmJuHqOg-aMghY-3f6xLgX53_mZGuqrhJ36wlohgy64HTGlhuK8Xeg7eybN6MtuGWP62k4aN6EeDPPNT0_VL4T-GpQ.webp",
                "group": "🇰🇷| Hàn Quốc",
                "url": "http://211.33.246.4:32954/cj_live/myStream.sdp/playlist.m3u8"
            },
            {
                "name": "MBC Daegu",
                "logo": "https://imgs.jobkorea.co.kr/img1/_whitebg/200X80/Co_Logo/Logo/2018/8/3/2r1wp00cPs_aWuzporsudz4s2os0ipMuSr_mvdfgo2ps.jpg?v=202607081751&hash=r&serviceCode=CL",
                "group": "🇰🇷| Hàn Quốc",
                "url": "https://5ee1ec6f32118.streamlock.net/live/livetv/playlist.m3u8"
            },
            {
                "name": "MBC Jeju",
                "logo": "https://jejumbc.com/main/images/news/jj1.jpg",
                "group": "🇰🇷| Hàn Quốc",
                "url": "https://wowza.jejumbc.com/live/tv_jejumbc/playlist.m3u8"
            },
            {
                "name": "MBC Mokpo",
                "logo": "https://upload.wikimedia.org/wikipedia/commons/thumb/0/0e/Munhwa_Broadcasting_Corporation.svg/960px-Munhwa_Broadcasting_Corporation.svg.png",
                "group": "🇰🇷| Hàn Quốc",
                "url": "http://vod.mpmbc.co.kr:1935/live/encoder-tv/playlist.m3u8"
            },
            {
                "name": "MBC Yeosu",
                "logo": "https://upload.wikimedia.org/wikipedia/commons/b/b8/MBC_logo.png",
                "group": "🇰🇷| Hàn Quốc",
                "url": "https://5c3639aa99149.streamlock.net/live_TV/tv/playlist.m3u8"
            },
            {
                "name": "EBS1",
                "logo": "https://logowik.com/content/uploads/images/ebs1-20181732222724.logowik.com.webp",
                "group": "🇰🇷| Hàn Quốc",
                "url": "https://ebsonair.ebs.co.kr/ebs1familypc/familypc1m/playlist.m3u8"
            },
            {
                "name": "EBS2",
                "logo": "https://upload.wikimedia.org/wikipedia/commons/thumb/d/db/EBS_2TV_Logo.svg/960px-EBS_2TV_Logo.svg.png",
                "group": "🇰🇷| Hàn Quốc",
                "url": "https://ebsonair.ebs.co.kr/ebs2familypc/familypc1m/playlist.m3u8"
            },
            {
                "name": "EBS E",
                "logo": "https://cdn.aptoide.com/imgs/6/7/e/67edd0054bd79fb633b11710eeeba298_fgraphic.png",
                "group": "🇰🇷| Hàn Quốc",
                "url": "https://ebsonair.ebs.co.kr/plus3familypc/familypc1m/playlist.m3u8"
            },
            {
                "name": "EBS Kids",
                "logo": "https://i.ytimg.com/vi/pra1kNRrxgc/hq720.jpg",
                "group": "🇰🇷| Hàn Quốc",
                "url": "https://ebsonair.ebs.co.kr/ebsufamilypc/familypc1m/playlist.m3u8"
            },
            {
                "name": "EBS+1",
                "logo": "https://static.wikia.nocookie.net/logopedia/images/7/70/Channels_IPTV_01.png/revision/latest?cb=20180627174859",
                "group": "🇰🇷| Hàn Quốc",
                "url": "https://ebsonair.ebs.co.kr/plus1familypc/familypc1m/playlist.m3u8"
            },
            {
                "name": "EBS+2",
                "logo": "https://static.wikia.nocookie.net/logopedia/images/5/5c/Channels_IPTV_02.png/revision/latest?cb=20180627175021",
                "group": "🇰🇷| Hàn Quốc",
                "url": "https://ebsonair.ebs.co.kr/plus2familypc/familypc1m/playlist.m3u8"
            },
            {
                "name": "TV Chosun",
                "logo": "https://upload.wikimedia.org/wikipedia/commons/thumb/1/1e/TV_Chosun_Logo_%28English%29.svg/1280px-TV_Chosun_Logo_%28English%29.svg.png",
                "group": "🇰🇷| Hàn Quốc",
                "url": "http://onair.cdn.tvchosun.com/origin1/_definst_/tvchosun_s1/playlist.m3u8",
                "headers": {
                    "Referer": "http://broadcast.tvchosun.com/onair/on.cstv"
                }
            },
            {
                "name": "TV Chosun 2",
                "logo": "https://www.bntnews.co.kr/data/bnt/image/201811/ab30063c0cd3b45d2fec9cd829c428e5.jpg",
                "group": "🇰🇷| Hàn Quốc",
                "url": "http://onair.cdn.tvchosun.com/origin1/_definst_/tvchosun_s1/playlist.m3u8",
                "headers": {
                    "Referer": "http://broadcast.tvchosun.com/onair/on.cstv"
                }
            },
            {
                "name": "TVN",
                "logo": "https://upload.wikimedia.org/wikipedia/commons/8/83/TVN_Logo.png",
                "group": "🇰🇷| Hàn Quốc",
                "url": "http://onair2.cdn.tvchosun.com/origin2/_definst_/tvchosun_s3/playlist.m3u8",
                "headers": {
                    "Referer": "http://broadcast.tvchosun.com/onair/on2.cstv"
                }
            }
        ],
        "🇨🇳| Trung Quốc": [
            {
                "name": "CCTV2",
                "logo": "https://upload.wikimedia.org/wikipedia/he/2/2f/1920px-CCTV-2_Logo.svg.png",
                "group": "🇨🇳| Trung Quốc",
                "url": "http://74.91.26.218:82/live/cctv2hd.m3u8"
            },
            {
                "name": "CCTV3",
                "logo": "https://static.wikia.nocookie.net/logos/images/f/f2/CCTV3.png/revision/latest/scale-to-width-down/680?cb=20230514030148&path-prefix=vi",
                "group": "🇨🇳| Trung Quốc",
                "url": "http://74.91.26.218:82/live/cctv3hd.m3u8"
            },
            {
                "name": "CCTV4",
                "logo": "https://static.wikia.nocookie.net/logos/images/d/da/CCTV4.png/revision/latest?cb=20230520135601&path-prefix=vi",
                "group": "🇨🇳| Trung Quốc",
                "url": "http://74.91.26.218:82/live/cctv4hd.m3u8"
            },
            {
                "name": "CCTV6",
                "logo": "https://static.wikia.nocookie.net/logos/images/d/d9/CCTV6.png/revision/latest?cb=20230816063202&path-prefix=vi",
                "group": "🇨🇳| Trung Quốc",
                "url": "http://74.91.26.218:82/live/cctv6hd.m3u8"
            },
            {
                "name": "CCTV7",
                "logo": "https://static.wikia.nocookie.net/logos/images/a/a6/CCTV7_tr%C6%B0%E1%BB%9Bc_2019.png/revision/latest/scale-to-width-down/1547?cb=20230104111736&path-prefix=vi",
                "group": "🇨🇳| Trung Quốc",
                "url": "http://74.91.26.218:82/live/cctv7hd.m3u8"
            },
            {
                "name": "CCTV8",
                "logo": "https://www.tvchinese.net/uploads/tv/cctv8.jpg",
                "group": "🇨🇳| Trung Quốc",
                "url": "http://112.123.206.32:808/hls/10/index.m3u8"
            },
            {
                "name": "CCTV10",
                "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSmUMEKDTwahilfUCb6CEmVmyRG5vjn-1QAUQ&usqp=CAU",
                "group": "🇨🇳| Trung Quốc",
                "url": "http://jxcbn.ws-cdn.gitv.tv/hls/CCTV10HD/index.m3u8?gMac=unknown&livodToken=fabd3816e5335ddba8d1d88c9536a13c2675337479957dee07e669564a88f4e7_1720504638_604800&fromCDN=ws"
            },
            {
                "name": "h_550/cctv11_logo_by_amazingtoludada3000_dew5uz3-fullview.png?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7ImhlaWdodCI6Ijw9NTUwIiwicGF0aCI6IlwvZlwvZWNkNTEyNjMtYmIwZi00NDY1LWFmODYtZjdlZDI1ZTU4ZTcwXC9kZXc1dXozLTBkM2YzY2FhLTdhYzItNGM5ZC1hYWY1LThhYTZhYmMzM2Y0Yi5wbmciLCJ3aWR0aCI6Ijw9MTI4MCJ9XV0sImF1ZCI6WyJ1cm46c2VydmljZTppbWFnZS5vcGVyYXRpb25zIl19.8ug6Sn5aUfjIJREthEuWeK0cIMretxYjCpnyiH0U2BM\", CCTV11",
                "logo": "https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/ecd51263-bb0f-4465-af86-f7ed25e58e70/dew5uz3-0d3f3caa-7ac2-4c9d-aaf5-8aa6abc33f4b.png/v1/fill/w_1280,h_550/cctv11_logo_by_amazingtoludada3000_dew5uz3-fullview.png?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7ImhlaWdodCI6Ijw9NTUwIiwicGF0aCI6IlwvZlwvZWNkNTEyNjMtYmIwZi00NDY1LWFmODYtZjdlZDI1ZTU4ZTcwXC9kZXc1dXozLTBkM2YzY2FhLTdhYzItNGM5ZC1hYWY1LThhYTZhYmMzM2Y0Yi5wbmciLCJ3aWR0aCI6Ijw9MTI4MCJ9XV0sImF1ZCI6WyJ1cm46c2VydmljZTppbWFnZS5vcGVyYXRpb25zIl19.8ug6Sn5aUfjIJREthEuWeK0cIMretxYjCpnyiH0U2BM",
                "group": "🇨🇳| Trung Quốc",
                "url": "http://jxcbn.ws-cdn.gitv.tv/hls/CCTV11HD/index.m3u8?gMac=unknown&livodToken=0034ae2fe24df5a14eb68b5de40ac5b36ab49542913cb5b015ae64ff49312f97_1720504669_604800&fromCDN=ws"
            },
            {
                "name": "CCTV12",
                "logo": "https://static.wikia.nocookie.net/logos/images/7/7b/CCTV12.png/revision/latest/scale-to-width-down/1131?cb=20230513114830&path-prefix=vi",
                "group": "🇨🇳| Trung Quốc",
                "url": "http://jxcbn.ws-cdn.gitv.tv/hls/CCTV12HD/index.m3u8?gMac=unknown&livodToken=2c98acaa80392eb7cfc5167a9a71482882518255259852ee6387715d5104fd23_1720504686_604800&fromCDN=ws"
            },
            {
                "name": "CCTV13",
                "logo": "https://static.wikia.nocookie.net/logos/images/e/e4/CCTV13.png/revision/latest/scale-to-width-down/1131?cb=20230513114844&path-prefix=vi",
                "group": "🇨🇳| Trung Quốc",
                "url": "http://112.123.206.32:808/hls/14/index.m3u8"
            },
            {
                "name": "CCTV14",
                "logo": "https://static.wikia.nocookie.net/happy-heroes/images/c/c8/CCTV-14_Logo.png/revision/latest?cb=20201002050804",
                "group": "🇨🇳| Trung Quốc",
                "url": "http://jxcbn.ws-cdn.gitv.tv/hls/CCTV14HD/index.m3u8?gMac=unknown&livodToken=0d96180497a13efbadc909954e682aae4e63affa0ef1823b5c6dc5a73b461db4_1720504729_604800&fromCDN=ws"
            },
            {
                "name": "CCTV15",
                "logo": "https://i.imgur.com/MXep2Zc.png",
                "group": "🇨🇳| Trung Quốc",
                "url": "http://jxcbn.ws-cdn.gitv.tv/hls/CCTV15/index.m3u8?gMac=unknown&livodToken=bde6e809b30a2e9d5be77b50b95f7634e4524e2a06f94bbcec4356d0f5b54ae3_1720508275_604800&fromCDN=ws"
            },
            {
                "name": "CCTV16",
                "logo": "https://static.wikia.nocookie.net/logopedia/images/3/39/CCTV-16.png/revision/latest?cb=20211107032828",
                "group": "🇨🇳| Trung Quốc",
                "url": "http://ottrrs.hl.chinamobile.com/PLTV/88888888/224/3221226100/index.m3u8"
            },
            {
                "name": "CCTV17",
                "logo": "https://i.imgur.com/omJsYRq.png",
                "group": "🇨🇳| Trung Quốc",
                "url": "http://ottrrs.hl.chinamobile.com/PLTV/88888888/224/3221225765/index.m3u8"
            },
            {
                "name": "CCTV4K",
                "logo": "https://i.imgur.com/Dmt78gy.png",
                "group": "🇨🇳| Trung Quốc",
                "url": "https://stream1.freetv.fun/3171fa435d942f1b7fa6ec05780f8def6705a20b23dc5bd6a43be7f63f6dd781.m3u8"
            },
            {
                "name": "CCTV8K",
                "logo": "https://pic2.zhimg.com/80/v2-01c9b1cdd4534f653e1bb8102b18a89d_1440w.webp",
                "group": "🇨🇳| Trung Quốc",
                "url": "https://epg.pw/stream/51549059a33a0dc4ac8d112ebbe3b1df956d95319a9ee54b6ca449c464893da5.m3u8"
            }
        ],
        "🇹🇭| Thái Lan": [
            {
                "name": "PPTV36",
                "logo": "https://image.makewebcdn.com/makeweb/m_1920x0/fwsVrxqVa/3PPTV36/PPTV_By_HSTN.jpg",
                "group": "🇹🇭| Thái Lan",
                "url": "https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/chpptvhd3/index.m3u8"
            },
            {
                "name": "MONO 29",
                "logo": "https://upload.wikimedia.org/wikipedia/commons/d/d5/Mono_29_Logo.png",
                "group": "🇹🇭| Thái Lan",
                "url": "https://cdn6.goprimetime.info/feed/eI5rczhSQpWBcgOtqRLNWw/chmono293/index.m3u8"
            },
            {
                "name": "Thairath TV 32",
                "logo": "https://www.thairath.co.th/assets/tv/img/share_tv.jpg",
                "group": "🇹🇭| Thái Lan",
                "url": "http://ch-4k-top.org:80/play/live.php?mac=00:1A:79:7a:39:a6&stream=1776225&extension=ts&play_token=TGCPfAlA9v"
            }
        ],
        "🇰🇭| Campuchia": [
            {
                "name": "Ramsey HangMeas Melody UHD",
                "logo": "https://1.bp.blogspot.com/-eaJhNFbzINk/XlhGheWJpgI/AAAAAAAAJ8M/k3fnwM6DPfso2q3pF8yzQWvg8ZScKF2dQCLcBGAsYHQ/s1600/HMHD.png",
                "group": "🇰🇭| Campuchia",
                "url": "http://abclive.malisresidences.com:1935/hmmel/_definst_/smil:hmmel.smil/playlist.m3u8"
            }
        ],
        "🔴 ⚽ COLA TV": [
            {
                "name": "BLV Aqua",
                "logo": "https://raw.githubusercontent.com/quanlehong539/VTC-Now/refs/heads/main/ColaTV_logo.png",
                "group": "🔴 ⚽ COLA TV",
                "url": "https://live05.msdht.app/live/18812304.m3u8",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            },
            {
                "name": "BLV Bí Đao",
                "logo": "https://raw.githubusercontent.com/quanlehong539/VTC-Now/refs/heads/main/ColaTV_logo.png",
                "group": "🔴 ⚽ COLA TV",
                "url": "https://live05.msdht.app/live/99121525.m3u8",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            },
            {
                "name": "BLV Casting",
                "logo": "https://raw.githubusercontent.com/quanlehong539/VTC-Now/refs/heads/main/ColaTV_logo.png",
                "group": "🔴 ⚽ COLA TV",
                "url": "https://live05.msdht.app/live/84753337.m3u8",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            },
            {
                "name": "BLV Coca",
                "logo": "https://raw.githubusercontent.com/quanlehong539/VTC-Now/refs/heads/main/ColaTV_logo.png",
                "group": "🔴 ⚽ COLA TV",
                "url": "https://live05.msdht.app/live/24561735.m3u8",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            },
            {
                "name": "BLV Cozy",
                "logo": "https://raw.githubusercontent.com/quanlehong539/VTC-Now/refs/heads/main/ColaTV_logo.png",
                "group": "🔴 ⚽ COLA TV",
                "url": "https://live05.msdht.app/live/87379114.m3u8",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            },
            {
                "name": "BLV C2",
                "logo": "https://raw.githubusercontent.com/quanlehong539/VTC-Now/refs/heads/main/ColaTV_logo.png",
                "group": "🔴 ⚽ COLA TV",
                "url": "https://live05.msdht.app/live/08552895.m3u8",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            },
            {
                "name": "BLV Dr Thanh",
                "logo": "https://raw.githubusercontent.com/quanlehong539/VTC-Now/refs/heads/main/ColaTV_logo.png",
                "group": "🔴 ⚽ COLA TV",
                "url": "https://live05.msdht.app/live/79665343.m3u8",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            },
            {
                "name": "BLV Fanta",
                "logo": "https://raw.githubusercontent.com/quanlehong539/VTC-Now/refs/heads/main/ColaTV_logo.png",
                "group": "🔴 ⚽ COLA TV",
                "url": "https://live05.msdht.app/live/71426314.m3u8",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            },
            {
                "name": "BLV Già Làng",
                "logo": "https://raw.githubusercontent.com/quanlehong539/VTC-Now/refs/heads/main/ColaTV_logo.png",
                "group": "🔴 ⚽ COLA TV",
                "url": "https://live05.msdht.app/live/14830711.m3u8",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            },
            {
                "name": "BLV Hổ Vằn",
                "logo": "https://raw.githubusercontent.com/quanlehong539/VTC-Now/refs/heads/main/ColaTV_logo.png",
                "group": "🔴 ⚽ COLA TV",
                "url": "https://live05.msdht.app/live/07428422.m3u8",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            },
            {
                "name": "BLV Không Độ",
                "logo": "https://raw.githubusercontent.com/quanlehong539/VTC-Now/refs/heads/main/ColaTV_logo.png",
                "group": "🔴 ⚽ COLA TV",
                "url": "https://live05.msdht.app/live/41943555.m3u8",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            },
            {
                "name": "BLV Lavie",
                "logo": "https://raw.githubusercontent.com/quanlehong539/VTC-Now/refs/heads/main/ColaTV_logo.png",
                "group": "🔴 ⚽ COLA TV",
                "url": "https://live05.msdht.app/live/75748097.m3u8",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            },
            {
                "name": "BLV Monster",
                "logo": "https://raw.githubusercontent.com/quanlehong539/VTC-Now/refs/heads/main/ColaTV_logo.png",
                "group": "🔴 ⚽ COLA TV",
                "url": "https://live05.msdht.app/live/75915087.m3u8",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            },
            {
                "name": "BLV Mountain Dew",
                "logo": "https://raw.githubusercontent.com/quanlehong539/VTC-Now/refs/heads/main/ColaTV_logo.png",
                "group": "🔴 ⚽ COLA TV",
                "url": "https://live05.msdht.app/live/87547578.m3u8",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            },
            {
                "name": "BLV Ôlong",
                "logo": "https://raw.githubusercontent.com/quanlehong539/VTC-Now/refs/heads/main/ColaTV_logo.png",
                "group": "🔴 ⚽ COLA TV",
                "url": "https://live05.msdht.app/live/97312754.m3u8",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            },
            {
                "name": "BLV Pepsi",
                "logo": "https://raw.githubusercontent.com/quanlehong539/VTC-Now/refs/heads/main/ColaTV_logo.png",
                "group": "🔴 ⚽ COLA TV",
                "url": "https://live05.msdht.app/live/43612277.m3u8",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            },
            {
                "name": "BLV Pocari",
                "logo": "https://raw.githubusercontent.com/quanlehong539/VTC-Now/refs/heads/main/ColaTV_logo.png",
                "group": "🔴 ⚽ COLA TV",
                "url": "https://live05.msdht.app/live/19919577.m3u8",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            },
            {
                "name": "BLV Redbull",
                "logo": "https://raw.githubusercontent.com/quanlehong539/VTC-Now/refs/heads/main/ColaTV_logo.png",
                "group": "🔴 ⚽ COLA TV",
                "url": "https://live05.msdht.app/live/68848594.m3u8",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            },
            {
                "name": "BLV Revive",
                "logo": "https://raw.githubusercontent.com/quanlehong539/VTC-Now/refs/heads/main/ColaTV_logo.png",
                "group": "🔴 ⚽ COLA TV",
                "url": "https://live05.msdht.app/live/33982309.m3u8",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            },
            {
                "name": "BLV Rockstar",
                "logo": "https://raw.githubusercontent.com/quanlehong539/VTC-Now/refs/heads/main/ColaTV_logo.png",
                "group": "🔴 ⚽ COLA TV",
                "url": "https://live05.msdht.app/live/82054853.m3u8",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            },
            {
                "name": "BLV Rồng Đỏ",
                "logo": "https://raw.githubusercontent.com/quanlehong539/VTC-Now/refs/heads/main/ColaTV_logo.png",
                "group": "🔴 ⚽ COLA TV",
                "url": "https://live05.msdht.app/live/88508431.m3u8",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            },
            {
                "name": "BLV Samurai",
                "logo": "https://raw.githubusercontent.com/quanlehong539/VTC-Now/refs/heads/main/ColaTV_logo.png",
                "group": "🔴 ⚽ COLA TV",
                "url": "https://live05.msdht.app/live/07808742.m3u8",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            },
            {
                "name": "BLV Soda",
                "logo": "https://raw.githubusercontent.com/quanlehong539/VTC-Now/refs/heads/main/ColaTV_logo.png",
                "group": "🔴 ⚽ COLA TV",
                "url": "https://live05.msdht.app/live/02456966.m3u8",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            },
            {
                "name": "BLV Sprite",
                "logo": "https://raw.githubusercontent.com/quanlehong539/VTC-Now/refs/heads/main/ColaTV_logo.png",
                "group": "🔴 ⚽ COLA TV",
                "url": "https://live05.msdht.app/live/90725470.m3u8",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            },
            {
                "name": "BLV Sting",
                "logo": "https://raw.githubusercontent.com/quanlehong539/VTC-Now/refs/heads/main/ColaTV_logo.png",
                "group": "🔴 ⚽ COLA TV",
                "url": "https://live05.msdht.app/live/14707124.m3u8",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            },
            {
                "name": "BLV 247",
                "logo": "https://raw.githubusercontent.com/quanlehong539/VTC-Now/refs/heads/main/ColaTV_logo.png",
                "group": "🔴 ⚽ COLA TV",
                "url": "https://live05.msdht.app/live/90865415.m3u8",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            },
            {
                "name": "BLV 7up",
                "logo": "https://raw.githubusercontent.com/quanlehong539/VTC-Now/refs/heads/main/ColaTV_logo.png",
                "group": "🔴 ⚽ COLA TV",
                "url": "https://live05.msdht.app/live/78905744.m3u8",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            }
        ]
    }
};
